# LOADBOOT OFFICIAL BRAND KIT — v2 (owner-selected 2026-07-02)
**SELECTED (owner-confirmed): the "lb" MONOGRAM + orange upward-arrow mark** — bold blue lowercase lb,
orange growth-arrow sweeping up through it, navy "loadboot" wordmark. Matches site palette exactly.

## Assets (Canva design DAHOQp0P1Oo)
- Edit/refine: https://www.canva.com/d/5Icnaa8WBW2OH0H
- View: https://www.canva.com/d/2LmqZQnKiuoQOLc
- Hi-res transparent PNG (2000px): download from the Canva design (Share → Download → PNG transparent).

## The 3 separable pieces (use independently where needed)
1. **ICON ONLY** (the navy arrow-mark + orange slash): favicons, app icons (192/512/maskable),
   avatars, watermarks, splash. Min size 16px. Clear space = 25% of mark width on all sides.
2. **TEXT LOGO ONLY** ("loadboot": "load" #0F172A on light / #fff on dark, "boot" #2563EB always):
   headers, documents, email signatures where the icon is redundant.
3. **FULL LOCKUP** (icon + wordmark): website header, portal auth cards, invoices, RC/dispatch sheets.

## OFFICIAL TAGLINE (chosen): "Keep Your Wheels Earning"
- Standalone use only (hero subtitles, ads, email footers) — NEVER attached to the lockup (canon rule).
- Color: orange #F97316 on light, #f9a86b on dark.

## Palette (matches site tokens)
Navy #0F172A · Blue #2563EB · Blue-light (dark bg) #60a5fa · Orange #F97316 · Slate #64748b · BG #f1f5f9

## Rules
- Never stretch, recolor outside palette, add shadows/gradients, or attach tagline to lockup.
- Dark backgrounds: white wordmark + blue-light "boot". Light: navy + blue.
- CURRENT SITE LOCKUP REMAINS CANON until owner explicitly orders the v2 rollout;
  rollout = one batch: site + 5 portals + PWA icons + favicons + og:image + splash.
