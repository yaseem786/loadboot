import math, sys, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

U='/mnt/user-data/uploads/loadboot/'
W,H,FPS = 1920,1080,30
NAVY=(9,15,28); CARD=(19,31,54); ORANGE=(252,83,5); BLUE=(59,157,255); GREEN=(52,211,153)
RED=(248,113,113); WHITE=(255,255,255); MUT=(138,158,192); LT=(226,236,250)
F  = lambda s,w='800': ImageFont.truetype(f'/tmp/fonts/manrope-{w}.ttf', s)
LOGO = Image.open(U+'logo-full-dark.png').convert('RGBA'); LOGO=LOGO.crop(LOGO.getbbox())
MARK = Image.open(U+'logo-icon-dark.png').convert('RGBA'); MARK=MARK.crop(MARK.getbbox())

# ---------- easing ----------
def c01(x): return 0.0 if x<0 else (1.0 if x>1 else x)
def eoc(t): t=c01(t); return 1-(1-t)**3
def eoq(t): t=c01(t); return 1-(1-t)**5
def eob(t,s=1.35):
    t=c01(t); return 1+ (s+1)*(t-1)**3 + s*(t-1)**2
def eic(t):
    t=c01(t); return 4*t*t*t if t<0.5 else 1-((-2*t+2)**3)/2
def seg(f,a,b): return c01((f-a)/max(1,(b-a)))
def mix(c1,c2,a): return tuple(int(c1[i]+(c2[i]-c1[i])*a) for i in range(3))

# ---------- background (cheap: low-res glow upscaled) ----------
_BG_CACHE={}
def bg(frame):
    key = frame//5
    if key in _BG_CACHE: return _BG_CACHE[key].copy()
    sw,sh = 240,135
    g = Image.new('RGB',(sw,sh),NAVY); gd=ImageDraw.Draw(g)
    t = frame/ (FPS*60.0)
    # two slow-drifting glows
    x1 = sw*(0.30+0.10*math.sin(t*2.1)); y1 = sh*(0.32+0.09*math.cos(t*1.7))
    x2 = sw*(0.74+0.08*math.cos(t*1.3)); y2 = sh*(0.70+0.07*math.sin(t*2.4))
    gd.ellipse([x1-70,y1-70,x1+70,y1+70], fill=(20,44,80))
    gd.ellipse([x2-58,y2-58,x2+58,y2+58], fill=(30,26,44))
    g = g.filter(ImageFilter.GaussianBlur(26)).resize((W,H), Image.BICUBIC)
    im = g.convert('RGB')
    # vignette + dot grid baked once
    if 'dots' not in _BG_CACHE:
        dl = Image.new('L',(W,H),0); dd=ImageDraw.Draw(dl)
        for yy in range(0,H,54):
            for xx in range(0,W,54): dd.ellipse([xx,yy,xx+2,yy+2], fill=16)
        _BG_CACHE['dots']=dl
        vg = Image.new('L',(W,H),0); vd=ImageDraw.Draw(vg)
        vd.ellipse([-W*0.35,-H*0.45,W*1.35,H*1.45], fill=255)
        _BG_CACHE['vig']=vg.filter(ImageFilter.GaussianBlur(180))
    im.paste((255,255,255), (0,0), _BG_CACHE['dots'])
    im = Image.composite(im, Image.new('RGB',(W,H),(4,7,14)), _BG_CACHE['vig'])
    _BG_CACHE[key]=im
    if len(_BG_CACHE)>12:
        for k in list(_BG_CACHE.keys()):
            if isinstance(k,int) and k<key-2: del _BG_CACHE[k]
    return im.copy()

# ---------- helpers ----------
def L(d, xy, txt, font, fill, anchor='lm', alpha=1.0, base=None):
    if alpha<=0.01: return
    if alpha>=0.995: d.text(xy, txt, font=font, fill=fill, anchor=anchor); return
    bb = d.textbbox(xy, txt, font=font, anchor=anchor)
    x0,y0,x1,y1 = int(bb[0])-8,int(bb[1])-8,int(bb[2])+8,int(bb[3])+8
    x0=max(0,x0); y0=max(0,y0); x1=min(W,x1); y1=min(H,y1)
    if x1<=x0 or y1<=y0: return
    lay = Image.new('RGBA',(x1-x0,y1-y0),(0,0,0,0)); ld=ImageDraw.Draw(lay)
    ld.text((xy[0]-x0,xy[1]-y0), txt, font=font, fill=fill+(int(255*alpha),), anchor=anchor)
    base.alpha_composite(lay,(x0,y0))

def ARROW(base,d,x,y,w=42,col=(255,255,255),alpha=1.0,th=6):
    """clean drawn arrow (Manrope has no proper arrow glyph)"""
    lay=Image.new('RGBA',(w+16,40),(0,0,0,0)); l=ImageDraw.Draw(lay)
    c=col+(int(255*alpha),)
    l.line([(4,20),(w-10,20)],fill=c,width=th)
    l.polygon([(w-14,20-9),(w+2,20),(w-14,20+9)],fill=c)
    base.alpha_composite(lay,(int(x),int(y-20)))
    return w+16

def card(base, box, radius=22, fill=CARD, outline=(255,255,255), ow=2, oa=0.16, alpha=1.0, glow=None):
    if alpha<=0.01: return
    pad=40
    x0=max(0,int(box[0])-pad); y0=max(0,int(box[1])-pad)
    x1=min(W,int(box[2])+pad); y1=min(H,int(box[3])+pad)
    if x1<=x0 or y1<=y0: return
    b=[box[0]-x0,box[1]-y0,box[2]-x0,box[3]-y0]
    lay = Image.new('RGBA',(x1-x0,y1-y0),(0,0,0,0)); ld=ImageDraw.Draw(lay)
    if glow:
        gl = Image.new('RGBA',(x1-x0,y1-y0),(0,0,0,0)); gd=ImageDraw.Draw(gl)
        gd.rounded_rectangle([b[0]-6,b[1]-6,b[2]+6,b[3]+6], radius=radius+6, fill=glow+(70,))
        gl = gl.filter(ImageFilter.GaussianBlur(20)); lay.alpha_composite(gl); ld=ImageDraw.Draw(lay)
    ld.rounded_rectangle(b, radius=radius, fill=fill+(int(248*alpha),),
                         outline=outline+(int(255*oa*alpha),), width=ow)
    if alpha<0.995:
        lay.putalpha(lay.getchannel('A').point(lambda p:int(p*alpha)))
    base.alpha_composite(lay,(x0,y0))

def logo_mark(base, x, y, h, alpha=1.0):
    m = MARK.resize((int(MARK.width*h/MARK.height), h), Image.LANCZOS)
    if alpha<0.999: m.putalpha(m.getchannel('A').point(lambda p:int(p*alpha)))
    base.alpha_composite(m,(int(x),int(y)))

def logo_full(base, x, y, w, alpha=1.0):
    lg = LOGO.resize((w,int(LOGO.height*w/LOGO.width)), Image.LANCZOS)
    if alpha<0.999: lg.putalpha(lg.getchannel('A').point(lambda p:int(p*alpha)))
    base.alpha_composite(lg,(int(x),int(y)))

def corner_logo(base, a=1.0):
    logo_full(base, 92, 74, 230, a*0.92)

def kinetic(base, d, x, y, txt, size, fill, p, weight='800', anchor='lm'):
    """slide-up + fade word block"""
    a = eoc(p); dy = (1-eoc(p))*46
    L(d,(x,y+dy),txt,F(size,weight),fill,anchor,a,base)

def chip(base, x, y, txt, col, fs=30, p=1.0, sym=None):
    a=eoc(p); 
    if a<=0.01: return 0
    f=F(fs,'700'); dtmp=ImageDraw.Draw(base)
    w=dtmp.textlength(txt,font=f); ex = fs+14 if sym else 0
    box=[x,y,x+w+56+ex,y+fs+34]
    sc = 0.94+0.06*eob(p)
    card(base, box, radius=(fs+34)//2, fill=mix(col,NAVY,0.16), outline=col, ow=3, oa=1.0, alpha=a)
    d2=ImageDraw.Draw(base); tx=x+28
    if sym:
        L(d2,(tx,y+17+fs//2),sym,F(fs,'800'),col,'lm',a,base); tx+=fs+14
    L(d2,(tx,y+17+fs//2),txt,f,mix(col,WHITE,.3),'lm',a,base)
    return w+56+ex

def frame(n):
    im = bg(n).convert('RGBA')
    d = ImageDraw.Draw(im)
    S = lambda s: int(s*FPS)

    # ================= S1 0-6s : HOOK =================
    if n < S(6.6):
        out = 1-eic(seg(n,S(5.9),S(6.5)))
        oy  = -eic(seg(n,S(5.9),S(6.5)))*90
        corner_logo(im, out)
        kinetic(im,d,140,int(400+oy),"You waited 4 hours", 118, WHITE, seg(n,S(0.5),S(1.6)))
        kinetic(im,d,140,int(530+oy),"at the dock.", 118, WHITE, seg(n,S(0.85),S(2.0)))
        kinetic(im,d,140,int(680+oy),'"We never got your screenshot."', 54, RED, seg(n,S(2.6),S(3.8)),'700')
        p4=seg(n,S(3.6),S(4.6))
        kinetic(im,d,140,int(752+oy),"— every broker, every time", 38, MUT, p4,'700')

    # ================= S2 6-15s : THE PROBLEM =================
    if S(5.9) <= n < S(15.4):
        a_in  = eoc(seg(n,S(6.1),S(7.0)))
        a_out = 1-eic(seg(n,S(14.7),S(15.3)))
        A = min(a_in,a_out); oy = (1-a_in)*70 - eic(seg(n,S(14.7),S(15.3)))*90
        corner_logo(im, A)
        kinetic(im,d,140,int(300+oy),"Detention is real money.", 76, WHITE, seg(n,S(6.3),S(7.4)))
        kinetic(im,d,140,int(372+oy),"Most of it never gets billed.", 46, MUT, seg(n,S(6.9),S(8.0)),'700')
        # big counter
        pc = seg(n,S(7.6),S(12.4))
        hrs = 4.0*eoc(pc); amt = 187.50*eoc(pc)
        bx=[140,int(470+oy),920,int(880+oy)]
        card(im,bx,26,alpha=A,glow=ORANGE if pc>0.9 else None)
        d2=ImageDraw.Draw(im)
        L(d2,(190,int(545+oy)),"TIME AT DOCK",F(30,'800'),MUT,'lm',A,im)
        L(d2,(190,int(640+oy)),f"{hrs:0.1f} hrs",F(104),WHITE,'lm',A,im)
        L(d2,(190,int(745+oy)),"UNPAID DETENTION",F(30,'800'),MUT,'lm',A*eoc(seg(n,S(9.0),S(9.8))),im)
        L(d2,(190,int(830+oy)),f"${amt:,.2f}",F(84),ORANGE,'lm',A*eoc(seg(n,S(9.0),S(9.8))),im)
        # right stat
        p2=seg(n,S(11.0),S(12.2))
        card(im,[980,int(470+oy),1780,int(880+oy)],26,alpha=A*eoc(p2))
        L(d2,(1030,int(560+oy)),"AVERAGE OWNER-OPERATOR",F(28,'800'),MUT,'lm',A*eoc(p2),im)
        L(d2,(1030,int(660+oy)),"$4,800+",F(96),RED,'lm',A*eoc(seg(n,S(11.4),S(12.6))),im)
        L(d2,(1030,int(760+oy)),"left on the table per year",F(38,'700'),LT,'lm',A*eoc(seg(n,S(11.8),S(13.0))),im)
        L(d2,(1030,int(820+oy)),"because the paperwork didn't exist",F(30,'700'),MUT,'lm',A*eoc(seg(n,S(12.1),S(13.3))),im)

    # ================= S3 15-33s : THE 3 STEPS =================
    if S(14.8) <= n < S(33.6):
        a_in  = eoc(seg(n,S(15.0),S(15.9)))
        a_out = 1-eic(seg(n,S(32.9),S(33.5)))
        A=min(a_in,a_out); oy=(1-a_in)*70 - eic(seg(n,S(32.9),S(33.5)))*90
        corner_logo(im,A)
        kinetic(im,d,140,int(268+oy),"On LoadBoot, the clock runs itself.",64,WHITE,seg(n,S(15.2),S(16.4)))
        steps=[("Arrived 14:02","GPS-stamped automatically — no screenshots",BLUE,'pin',17.0),
               ("Free time ends 16:02","written on the rate con before you booked",ORANGE,'clock',20.6),
               ("+$187.50 detention","claim filed with evidence — added to your invoice",GREEN,'check',24.2)]
        y0=int(380+oy)
        for i,(t1,t2,col,ic,st) in enumerate(steps):
            p=seg(n,S(st),S(st+1.3)); a=A*eoc(p)
            if a<=0.01: continue
            yy=y0+i*208; dx=(1-eoc(p))*70
            card(im,[140+dx,yy,1780+dx,yy+168],24,alpha=a,glow=col if p>0.55 else None)
            d2=ImageDraw.Draw(im)
            ld=ImageDraw.Draw(im)
            cx,cy=240+dx,yy+84
            lay=Image.new('RGBA',(120,120),(0,0,0,0)); l2=ImageDraw.Draw(lay)
            ox,oy2=cx-60,cy-60; C=lambda X,Y:(X-ox,Y-oy2)
            A_=int(255*a); WI=WHITE+(A_,)
            l2.ellipse([C(cx-42,cy-42),C(cx+42,cy+42)], fill=col+(A_,))
            if ic=='pin':
                l2.ellipse([C(cx-17,cy-17),C(cx+17,cy+17)], outline=WI, width=6)
                l2.ellipse([C(cx-5,cy-5),C(cx+5,cy+5)], fill=WI)
            elif ic=='clock':
                l2.ellipse([C(cx-20,cy-20),C(cx+20,cy+20)], outline=WI, width=5)
                ang=-math.pi/2 + ((n%(FPS*2))/(FPS*2))*2*math.pi
                l2.line([C(cx,cy),C(cx+13*math.cos(ang),cy+13*math.sin(ang))], fill=WI, width=5)
                l2.line([C(cx,cy),C(cx,cy-9)], fill=WI, width=5)
            else:
                l2.line([C(cx-17,cy+2),C(cx-5,cy+15),C(cx+19,cy-14)], fill=WI, width=9, joint='curve')
            im.alpha_composite(lay,(int(ox),int(oy2)))
            d2=ImageDraw.Draw(im)
            L(d2,(320+dx,yy+62),t1,F(50),WHITE,'lm',a,im)
            L(d2,(320+dx,yy+124),t2,F(33,'700'),MUT,'lm',a,im)
            if i<2:
                pl=seg(n,S(st+1.0),S(st+1.7))
                if pl>0:
                    lay2=Image.new('RGBA',(W,H),(0,0,0,0)); l3=ImageDraw.Draw(lay2)
                    l3.line([(240,yy+168),(240,yy+168+int(40*eoc(pl)))], fill=(120,142,180,int(220*A)), width=5)
                    im.alpha_composite(lay2)
        p_end=seg(n,S(29.4),S(30.6))
        kinetic(im,d,140,int(1000+oy),"No arguing. No screenshots. Just paid.",44,LT,p_end,'700')

    # ================= S4 33-46s : INVOICE =================
    if S(33.0) <= n < S(46.6):
        a_in=eoc(seg(n,S(33.2),S(34.1))); a_out=1-eic(seg(n,S(45.9),S(46.5)))
        A=min(a_in,a_out); oy=(1-a_in)*70 - eic(seg(n,S(45.9),S(46.5)))*90
        corner_logo(im,A)
        kinetic(im,d,140,int(250+oy),"It lands on the invoice by itself.",64,WHITE,seg(n,S(33.4),S(34.6)))
        bx=[420,int(360+oy),1500,int(880+oy)]
        card(im,bx,28,alpha=A,glow=BLUE if seg(n,S(35),S(36))>0.5 else None)
        d2=ImageDraw.Draw(im)
        ah=A*eoc(seg(n,S(34.4),S(35.4))); fh=F(30,'800')
        L(d2,(470,int(432+oy)),"INVOICE #4471 · Dallas, TX",fh,MUT,'lm',ah,im)
        axx=470+d2.textlength("INVOICE #4471 · Dallas, TX",font=fh)+14
        aw=ARROW(im,d2,axx,int(432+oy),34,MUT,ah,4)
        L(ImageDraw.Draw(im),(axx+aw,int(432+oy)),"Atlanta, GA",fh,MUT,'lm',ah,im)
        rows=[("Linehaul","$2,850.00",WHITE,36.0),("Detention (2.0 hrs @ $93.75)","$187.50",GREEN,37.6),
              ("Lumper (receipt attached)","$125.00",GREEN,39.0)]
        yy=int(510+oy)
        for lbl,val,col,st in rows:
            p=eoc(seg(n,S(st),S(st+0.9))); dx=(1-p)*40
            L(d2,(470+dx,yy),lbl,F(38,'700'),LT,'lm',A*p,im)
            L(d2,(1450+dx,yy),val,F(44),col,'rm',A*p,im)
            yy+=74
        pl=eoc(seg(n,S(40.4),S(41.2)))
        if pl>0:
            lay=Image.new('RGBA',(W,H),(0,0,0,0)); l2=ImageDraw.Draw(lay)
            l2.line([(470,int(748+oy)),(470+int(980*pl),int(748+oy))], fill=(255,255,255,int(50*A)), width=3)
            im.alpha_composite(lay); d2=ImageDraw.Draw(im)
        pt=seg(n,S(41.0),S(43.4)); tot=3162.50*eoc(pt)
        L(d2,(470,int(818+oy)),"TOTAL",F(38,'800'),MUT,'lm',A*eoc(seg(n,S(41.0),S(41.8))),im)
        L(d2,(1450,int(818+oy)),f"${tot:,.2f}",F(66),WHITE,'rm',A*eoc(seg(n,S(41.0),S(41.8))),im)
        chip(im,470,int(900+oy),"100% of accessorials pass through to you",GREEN,30,seg(n,S(43.4),S(44.4)),'✓')

    # ================= S5 46-60s : CTA =================
    if n >= S(45.9):
        a=eoc(seg(n,S(46.1),S(47.2)))
        sc=0.92+0.08*eob(seg(n,S(46.1),S(47.6)))
        lw=int(560*sc)
        logo_full(im, W//2-lw//2, int(300-(1-a)*40), lw, a)
        kinetic(im,d,W//2,548,"Detention pay that pays.",76,WHITE,seg(n,S(47.4),S(48.6)),'800','mm')
        kinetic(im,d,W//2,632,"Live loads · GPS proof · flat 5% dispatch · $0 monthly",42,MUT,seg(n,S(48.2),S(49.4)),'700','mm')
        p=seg(n,S(49.4),S(50.6)); ac=eoc(p)
        if ac>0.01:
            d2=ImageDraw.Draw(im); f=F(56,'800'); tw=d2.textlength("loadboot.com",font=f)
            pulse = 1+0.012*math.sin(n/FPS*3.1)
            bw=(tw+120)*pulse
            card(im,[W//2-bw/2,720,W//2+bw/2,820],50,fill=ORANGE,outline=ORANGE,ow=2,oa=1,alpha=ac,glow=ORANGE)
            L(ImageDraw.Draw(im),(W//2,770),"loadboot.com",f,WHITE,'mm',ac,im)
        kinetic(im,d,W//2,900,"Free verified accounts — carriers, brokers & shippers",34,MUT,seg(n,S(50.6),S(51.8)),'700','mm')

    return im.convert('RGB')

if __name__=='__main__':
    if sys.argv[1]=='test':
        for s in [1.4,3.9,8.5,12.8,18.5,26.0,31.0,37.0,43.0,48.5,52.0]:
            frame(int(s*FPS)).save(f'/home/user/video/t_{s}.jpg', quality=88)
        print('test frames done')
