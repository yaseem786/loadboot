import subprocess, sys, time, os
from multiprocessing import Pool
sys.path.insert(0,'/home/user/video')
FPS=30; DUR=319.0; N=int(DUR*FPS)
OUT='/home/user/video/loadboot-detention-FINAL-video.mp4'

_r=None
def init():
    global _r
    import render4; _r=render4

def job(i):
    return _r.frame(i).tobytes()

if __name__=='__main__':
    p=subprocess.Popen(['ffmpeg','-y','-f','rawvideo','-pix_fmt','rgb24','-s','1920x1080','-r','30',
      '-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p',
      '-movflags','+faststart',OUT],
      stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    t0=time.time()
    with Pool(2, initializer=init) as pool:
        for i,buf in enumerate(pool.imap(job, range(N), chunksize=12)):
            p.stdin.write(buf)
            if i%600==0:
                el=time.time()-t0
                eta=(N-i)*el/max(1,i) if i else 0
                print(f'{i}/{N}  {el:.0f}s  eta {eta/60:.1f}m',flush=True)
    p.stdin.close(); p.wait()
    print('DONE', time.time()-t0, os.path.getsize(OUT))
