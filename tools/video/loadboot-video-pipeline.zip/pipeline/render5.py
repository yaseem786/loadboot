"""v2 — same timeline, upgraded motion craft.
Import order matters: motion.install() must run BEFORE render4 (and the widget/clip
modules it pulls in) bind `card`/`kinetic` from render."""
import sys
sys.path.insert(0,'/home/user/video')
import motion
motion.install()                     # patch the shared primitives first
import render4                       # now picks up the patched card/kinetic
from render import FPS, W, H, eoc, seg, WHITE, ORANGE, GREEN
render4.sa = motion.sa               # vertical push instead of dip-to-black

S = lambda s: int(s*FPS)
DUR = render4.DUR

# specular passes over the numbers that carry the argument
SWEEPS = [
 (2.2,  3.6,  (130, 520, 900, 620)),      # "of detention."
 (22.7, 24.3, (150, 500, 700, 640)),      # $15.1B
 (66.0, 67.4, (150, 380, 700, 500)),      # 72%
 (91.5, 93.0, (1400,430, 1790, 520)),     # $66.65 / hr
 (97.0, 98.4, (130, 850, 1200, 940)),     # $3.65/hr underwater
 (267.0,268.6, (150, 900, 1500, 1010)),   # $8,000-$14,000 a year
 # ($64.00 now lives inside a panning portal screen — a fixed-box sweep can't track it)
 (301.0,302.4, (150, 380, 560, 480)),     # 100%
 (304.0,305.4, (150, 580, 480, 680)),     # 5%
]

import clips4

def _clip_active(n):
    return any(S(t0)-1 <= n < S(t1)+1 for t0,t1,*_ in clips4.SLOTS)

def frame(n):
    im = render4.frame(n).convert('RGBA')
    # the rail orients you between rule cards; during a product screen it is clutter
    # (and would run under the caption bar)
    if not _clip_active(n):
        motion.rail(im, n)
    t = n/float(FPS)
    for t0,t1,box in SWEEPS:
        if t0 <= t < t1:
            motion.sweep(im, box, (t-t0)/(t1-t0))
            break
    return im.convert('RGB')

if __name__=='__main__':
    for s in [3,23,31,66,92,98,120,131,148,171,192,205,220,236,258,268,284,290,297,303,310]:
        frame(int(s*FPS)).save(f'/home/user/video/m_{s}.jpg',quality=88)
    print('v2 stills ok')
