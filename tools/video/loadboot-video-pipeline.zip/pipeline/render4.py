"""LoadBoot detention explainer — FINAL. Timeline locked to the real Andrew-Neural voice track
(align.json sentence timings). 6 product clips from live portal screenshots baked in."""
import math, sys
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
from render import (bg, L, card, logo_full, corner_logo, kinetic, mix,
                    eoc, eob, eic, seg, F, W, H, FPS, LOGO, NAVY, CARD, ORANGE,
                    BLUE, GREEN, RED, WHITE, MUT, LT)
import clips4, widgets, widgets2
AMB=(251,191,36); S=lambda s:int(s*FPS)
DUR=319.0

def sa(n,a0,a1,b0,b1):
    ai=eoc(seg(n,S(a0),S(a1))); ao=eic(seg(n,S(b0),S(b1)))
    return min(ai,1-ao),(1-ai)*60-ao*80

def src(im,d,x,y,t,a=1.0): L(d,(x,y),t,F(25,'700'),(104,124,160),'lm',a,im)

def badge(im,n,num,col,A,x,y,label,t0):
    p0=eoc(seg(n,S(t0),S(t0+0.9)))
    lay=Image.new('RGBA',(200,200),(0,0,0,0)); l=ImageDraw.Draw(lay); aa=int(255*A*p0)
    l.rounded_rectangle([20,20,140,140],radius=30,fill=col+(aa,))
    l.text((80,80),str(num),font=F(64),fill=NAVY+(aa,),anchor='mm')
    im.alpha_composite(lay,(x,y))
    d=ImageDraw.Draw(im)
    L(d,(x+180,y+72),label,F(28,'800'),col,'lm',A*p0,im)
    return d

def tick(im,d,x,y,col,A,p,r=32):
    lay=Image.new('RGBA',(r*2+26,r*2+26),(0,0,0,0)); l=ImageDraw.Draw(lay); aa=int(255*A*p)
    l.ellipse([13,13,13+r*2,13+r*2],fill=col+(aa,))
    s=r/32.0
    l.line([(13+18*s,13+31*s),(13+29*s,13+43*s),(13+50*s,13+16*s)],fill=WHITE+(aa,),width=max(4,int(8*s)),joint='curve')
    im.alpha_composite(lay,(x,y))
    return ImageDraw.Draw(im)

def statrow(im,d,n,x,y,val,lbl,col,t0,A,srcname=None,w=800,h=108):
    p=eoc(seg(n,S(t0),S(t0+1.0)))
    if p<=.01: return
    dx=(1-p)*40
    card(im,[x+dx,y,x+w+dx,y+h],20,alpha=A*p,glow=col if p>.93 else None)
    d2=ImageDraw.Draw(im)
    L(d2,(x+40+dx,y+40),val,F(44),col,'lm',A*p,im)
    L(d2,(x+40+dx,y+82),lbl,F(27,'700'),LT,'lm',A*p,im)
    if srcname: L(d2,(x+w-30+dx,y+40),"— "+srcname,F(22,'700'),(104,124,160),'rm',A*p,im)

def frame(n):
    im=bg(n).convert('RGBA'); d=ImageDraw.Draw(im)

    # ================= A · HOOK  0 → 13.2 =================
    if n<S(13.4):
        A,oy=sa(n,0.3,1.2,12.6,13.3); corner_logo(im,A)
        kinetic(im,d,140,int(320+oy),"17% of truckers have never",104,WHITE,seg(n,0,S(1.3)))
        kinetic(im,d,140,int(442+oy),"been paid a single dollar",104,WHITE,seg(n,S(0.35),S(1.65)))
        kinetic(im,d,140,int(564+oy),"of detention.",104,ORANGE,seg(n,S(0.7),S(2.0)))
        src(im,d,140,int(642+oy),"— OOIDA member survey",A*eoc(seg(n,S(2.6),S(3.4))))
        kinetic(im,d,140,int(760+oy),"They waited.",56,RED,seg(n,S(4.3),S(5.4)))
        kinetic(im,d,140,int(830+oy),"They just couldn't prove it.",56,RED,seg(n,S(6.7),S(7.8)))
        kinetic(im,d,140,int(940+oy),"Here's how to prove it — every time.",42,MUT,seg(n,S(8.8),S(10.0)),'700')

    # ================= B1 · THE SCALE  13.2 → 43.65 =================
    if S(13.0)<=n<S(43.9):
        A,oy=sa(n,13.3,14.1,43.1,43.8); corner_logo(im,A)
        kinetic(im,d,140,int(210+oy),"Detention isn't a nuisance.",52,MUT,seg(n,S(13.4),S(14.5)),'700')
        kinetic(im,d,140,int(282+oy),"It's the biggest uncompensated cost in trucking.",56,WHITE,seg(n,S(15.2),S(16.4)))
        pc=seg(n,S(18.2),S(22.6)); v=15.1*eoc(pc)
        card(im,[140,int(400+oy),920,int(740+oy)],26,alpha=A,glow=RED if pc>.92 else None)
        L(d,(190,int(465+oy)),"LOST EVERY YEAR — US TRUCKING",F(27,'800'),MUT,'lm',A,im)
        L(d,(190,int(575+oy)),f"${v:0.1f}B",F(118),RED,'lm',A,im)
        src(im,d,190,int(680+oy),"— ATRI",A*eoc(seg(n,S(22.6),S(23.6))))
        statrow(im,d,n,980,int(400+oy),"$11.5B","in lost productivity",RED,24.4,A,"ATRI")
        statrow(im,d,n,980,int(524+oy),"$3.6B","in added expense",AMB,26.6,A,"ATRI")
        statrow(im,d,n,980,int(648+oy),"$11,000–$19,000","per driver, per year",ORANGE,29.9,A,"ATRI")
        statrow(im,d,n,140,int(800+oy),"39%","of deliveries hit detention",AMB,34.9,A,"ATRI 2023",w=780)
        statrow(im,d,n,980,int(800+oy),"< 50%","of billed detention is ever paid",RED,37.9,A,"DAT",w=800)

    # ================= B2 · SAFETY  43.65 → 62.97 =================
    if S(43.4)<=n<S(63.2):
        A,oy=sa(n,43.7,44.5,62.4,63.1)
        if A>0.01:
            ov=Image.new('RGBA',(W,H),(9,15,28,int(255*A))); im.alpha_composite(ov); d=ImageDraw.Draw(im)
            corner_logo(im,A)
            kinetic(im,d,140,int(250+oy),"And it isn't only money.",56,WHITE,seg(n,S(43.8),S(45.0)))
            p1=eoc(seg(n,S(45.5),S(46.8)))
            if p1>.01:
                card(im,[140,int(370+oy),1780,int(560+oy)],24,alpha=A*p1,glow=AMB if p1>.94 else None)
                d2=ImageDraw.Draw(im)
                L(d2,(190,int(438+oy)),"Every 15 minutes of extra dwell time",F(38,'700'),LT,'lm',A*p1,im)
                L(d2,(190,int(506+oy)),"raises crash risk by 6.2%",F(52),AMB,'lm',A*p1,im)
                L(d2,(1730,int(470+oy)),"— DOT Office of Inspector General",F(23,'700'),(104,124,160),'rm',A*p1,im)
            p2=eoc(seg(n,S(54.4),S(55.7)))
            if p2>.01:
                card(im,[140,int(600+oy),1780,int(790+oy)],24,alpha=A*p2,glow=RED if p2>.94 else None)
                d2=ImageDraw.Draw(im)
                L(d2,(190,int(668+oy)),"After being detained, drivers speed",F(38,'700'),LT,'lm',A*p2,im)
                L(d2,(190,int(736+oy)),"14.6% more",F(52),RED,'lm',A*p2,im)
                L(d2,(1730,int(700+oy)),"— ATRI",F(23,'700'),(104,124,160),'rm',A*p2,im)
            kinetic(im,d,140,int(890+oy),"The time you lose at the dock,",44,WHITE,seg(n,S(58.9),S(60.1)))
            kinetic(im,d,140,int(952+oy),"you try to make up on the road.",44,ORANGE,seg(n,S(60.2),S(61.4)))

    # ================= B3 · YOU'RE NOT THE EXCEPTION  62.97 → 82.95 =================
    if S(62.7)<=n<S(83.2):
        A,oy=sa(n,63.0,63.9,82.4,83.1)
        if A>0.01:
            ov=Image.new('RGBA',(W,H),(7,12,23,int(255*A))); im.alpha_composite(ov); d=ImageDraw.Draw(im)
            corner_logo(im,A)
            kinetic(im,d,140,int(250+oy),"You are not the exception.",68,WHITE,seg(n,S(63.1),S(64.4)))
            statrow(im,d,n,140,int(390+oy),"72%","of owner-operators wait 2+ hours every week",ORANGE,66.8,A,"OOIDA",w=1640,h=124)
            statrow(im,d,n,140,int(538+oy),"59%","of all drivers were detained in the last two weeks",AMB,71.3,A,"ATRI",w=1640,h=124)
            statrow(im,d,n,140,int(686+oy),"80%","of those then struggled to stay legal on hours of service",RED,75.5,A,"ATRI",w=1640,h=124)
            kinetic(im,d,140,int(880+oy),"This is the industry's normal.",46,MUT,seg(n,S(79.8),S(80.9)),'700')
            kinetic(im,d,140,int(950+oy),"It should not be yours.",46,ORANGE,seg(n,S(81.4),S(82.5)))

    # ================= C · THE MATH  82.95 → 108.05 =================
    if S(82.7)<=n<S(108.3):
        A,oy=sa(n,83.0,83.9,107.5,108.2)
        if A>0.01:
            ov=Image.new('RGBA',(W,H),(9,15,28,int(255*A))); im.alpha_composite(ov); d=ImageDraw.Draw(im)
            corner_logo(im,A)
            kinetic(im,d,140,int(250+oy),"The part nobody says out loud.",64,WHITE,seg(n,S(83.1),S(84.4)))
            bars=[("Detention bills at","$63.00 / hr",BLUE,.945,85.8),
                  ("An hour of truck costs","$66.65 / hr",RED,1.0,89.6)]
            yy=int(390+oy)
            for lbl,val,col,fr,st in bars:
                p=eoc(seg(n,S(st),S(st+1.2)))
                if p>.01:
                    card(im,[140,yy,1780,yy+170],24,alpha=A*p)
                    d2=ImageDraw.Draw(im)
                    L(d2,(190,yy+52),lbl,F(36,'700'),LT,'lm',A*p,im)
                    L(d2,(1730,yy+52),val,F(56),col,'rm',A*p,im)
                    gw=eoc(seg(n,S(st+0.6),S(st+2.2)))
                    lay=Image.new('RGBA',(W,H),(0,0,0,0)); l=ImageDraw.Draw(lay)
                    l.rounded_rectangle([190,yy+104,1730,yy+136],radius=16,fill=mix(col,CARD,.2)+(int(255*A*p),))
                    l.rounded_rectangle([190,yy+104,190+int(1540*fr*gw),yy+136],radius=16,fill=col+(int(255*A*p),))
                    im.alpha_composite(lay); d=ImageDraw.Draw(im)
                yy+=200
            kinetic(im,d,140,int(820+oy),"Even when it's paid in full,",48,WHITE,seg(n,S(94.8),S(96.0)))
            kinetic(im,d,140,int(886+oy),"you're still $3.65/hr underwater.",48,RED,seg(n,S(96.4),S(97.6)))
            kinetic(im,d,140,int(970+oy),"Detention isn't profit. It's damage control — so collect all of it.",36,MUT,seg(n,S(101.8),S(103.0)),'700')

    # ================= D · FIVE RULES  108.05 → 116.68 =================
    if S(107.8)<=n<S(116.9):
        A,oy=sa(n,108.1,108.9,116.2,116.85); corner_logo(im,A)
        kinetic(im,d,W//2,420,"Five rules.",96,WHITE,seg(n,S(109.2),S(110.4)),'800','mm')
        kinetic(im,d,W//2,540,"Follow all five and detention stops being a favour.",44,MUT,seg(n,S(110.0),S(111.3)),'700','mm')
        kinetic(im,d,W//2,600,"It becomes a bill they owe.",46,ORANGE,seg(n,S(115.3),S(116.4)),'700','mm')
        L(d,(W//2,740),"1  ·  2  ·  3  ·  4  ·  5",F(66),ORANGE,'mm',A*eoc(seg(n,S(112.0),S(113.4))),im)

    # ================= E1 · RULE 1  116.68 → 138.4 =================
    if S(116.4)<=n<S(138.6):
        A,oy=sa(n,116.7,117.5,138.0,138.55); corner_logo(im,A)
        d=badge(im,n,1,ORANGE,A,120,int(230+oy),"RULE 1 OF 5",116.8)
        kinetic(im,d,300,int(392+oy),"Get it in writing — before you book.",58,WHITE,seg(n,S(117.6),S(118.8)))
        kinetic(im,d,140,int(560+oy),"Verbal doesn't exist. Text barely does.",44,LT,seg(n,S(120.3),S(121.6)),'700')
        kinetic(im,d,140,int(632+oy),"It goes on the rate confirmation.",44,ORANGE,seg(n,S(122.8),S(124.1)),'700')
        p=eoc(seg(n,S(125.5),S(126.8)))
        if p>.01:
            card(im,[140,int(720+oy),1780,int(860+oy)],22,alpha=A*p,glow=ORANGE if p>.94 else None)
            d2=ImageDraw.Draw(im)
            L(d2,(190,int(772+oy)),"Write it yourself if you have to:",F(30,'700'),MUT,'lm',A*p,im)
            L(d2,(190,int(824+oy)),"\"Detention accrues 2 hours after appointment — $75/hr.\"",F(38,'700'),WHITE,'lm',A*p,im)

    # ================= E2 · RULE 1 QUOTE + TRAP  138.4 → 153.73 =================
    if S(138.2)<=n<S(153.95):
        A,oy=sa(n,138.5,139.3,153.3,153.9)
        if A>0.01:
            ov=Image.new('RGBA',(W,H),(9,15,28,int(255*A))); im.alpha_composite(ov); d=ImageDraw.Draw(im)
            corner_logo(im,A)
            L(d,(140,int(250+oy)),"FROM A 20-YEAR OWNER-OPERATOR",F(27,'800'),ORANGE,'lm',A*eoc(seg(n,S(138.7),S(139.6))),im)
            kinetic(im,d,140,int(350+oy),"\"If there is no agreement at all,",50,WHITE,seg(n,S(139.4),S(140.6)))
            kinetic(im,d,140,int(420+oy),"they can deny your detention —",50,WHITE,seg(n,S(140.4),S(141.6)))
            kinetic(im,d,140,int(490+oy),"and there is practically nothing you can do.\"",50,WHITE,seg(n,S(141.6),S(142.9)))
            p=eoc(seg(n,S(145.0),S(146.4)))
            if p>.01:
                card(im,[140,int(640+oy),1780,int(860+oy)],24,alpha=A*p,glow=RED if p>.94 else None)
                d2=ImageDraw.Draw(im)
                L(d2,(190,int(706+oy)),"⚠ THE TRAP",F(30,'800'),RED,'lm',A*p,im)
                L(d2,(190,int(778+oy)),"\"Accessorial pay is included in the linehaul rate.\"",F(42,'700'),WHITE,'lm',A*p,im)
                L(d2,(190,int(830+oy)),"Sign that, and you just signed your detention away.",F(30,'700'),MUT,'lm',A*p,im)

    # ================= F · RULE 2  153.73 → 166.0 =================
    if S(153.5)<=n<S(166.2):
        A,oy=sa(n,153.8,154.6,165.6,166.15); corner_logo(im,A)
        d=badge(im,n,2,BLUE,A,120,int(230+oy),"RULE 2 OF 5",153.9)
        kinetic(im,d,300,int(392+oy),"The clock starts at your on-time arrival.",56,WHITE,seg(n,S(154.7),S(155.9)))
        kinetic(im,d,140,int(570+oy),"Free time is 2 hours — but it assumes you showed up on time.",42,LT,seg(n,S(157.4),S(158.7)),'700')
        kinetic(im,d,140,int(646+oy),"Arrive late, and you've handed them the defence for free.",42,RED,seg(n,S(162.4),S(163.7)),'700')

    # ================= G · RULE 3  176.55 → 186.0 =================
    if S(176.1)<=n<S(186.2):
        A,oy=sa(n,176.25,177.0,185.5,186.15); corner_logo(im,A)
        d=badge(im,n,3,AMB,A,120,int(230+oy),"RULE 3 OF 5",176.7)
        kinetic(im,d,300,int(392+oy),"Notify before free time ends — not after.",56,WHITE,seg(n,S(177.2),S(178.4)))
        p1=eoc(seg(n,S(179.8),S(181.0))); p2=eoc(seg(n,S(182.9),S(184.1)))
        if p1>.01:
            card(im,[140,int(560+oy),940,int(700+oy)],22,alpha=A*p1,glow=GREEN if p1>.94 else None)
            d2=ImageDraw.Draw(im)
            L(d2,(190,int(612+oy)),"Hour 1:45",F(50),GREEN,'lm',A*p1,im)
            L(d2,(190,int(664+oy)),"is evidence",F(32,'700'),LT,'lm',A*p1,im)
        if p2>.01:
            card(im,[980,int(560+oy),1780,int(700+oy)],22,alpha=A*p2,glow=RED if p2>.94 else None)
            d2=ImageDraw.Draw(im)
            L(d2,(1030,int(612+oy)),"Hour 5",F(50),RED,'lm',A*p2,im)
            L(d2,(1030,int(664+oy)),"is a complaint",F(32,'700'),LT,'lm',A*p2,im)

    # ================= H · RULE 4 · FIVE PIECES OF EVIDENCE  198.61 → 215.26 =================
    if S(198.05)<=n<S(215.5):
        A,oy=sa(n,198.3,199.05,214.8,215.45); corner_logo(im,A)
        d=badge(im,n,4,GREEN,A,120,int(190+oy),"RULE 4 OF 5",198.8)
        kinetic(im,d,300,int(352+oy),"Five pieces of evidence. Every time.",56,WHITE,seg(n,S(199.2),S(200.4)))
        ev=[("GPS-stamped arrive & depart",201.5),
            ("Gate photo with a visible timestamp",203.6),
            ("BOL with in/out times — facility initialled",205.6),
            ("Gate ticket or receipt",209.7),
            ("Screenshot of the notice you sent in time",211.6)]
        yy=int(470+oy)
        for t,t0 in ev:
            p=eoc(seg(n,S(t0),S(t0+0.9)))
            if p>.01:
                d=tick(im,d,140,yy-42,GREEN,A,p)
                L(d,(250,yy),t,F(40,'700'),LT,'lm',A*p,im)
            yy+=94

    # ================= I · RULE 5  215.26 → 228.2  /  228.2 → 239.46 =================
    if S(215.0)<=n<S(228.4):
        A,oy=sa(n,215.3,216.1,227.9,228.35); corner_logo(im,A)
        d=badge(im,n,5,BLUE,A,120,int(230+oy),"RULE 5 OF 5",215.4)
        kinetic(im,d,300,int(392+oy),"Invoice it immediately — with the load.",56,WHITE,seg(n,S(216.3),S(217.5)))
        kinetic(im,d,140,int(566+oy),"Late invoicing is the #1 reason valid detention dies.",44,RED,seg(n,S(218.8),S(220.1)),'700')
        p=eoc(seg(n,S(223.0),S(224.3)))
        if p>.01:
            dx=(1-p)*50
            card(im,[140+dx,int(680+oy),1780+dx,int(860+oy)],22,alpha=A*p,glow=BLUE if p>.94 else None)
            d=tick(im,d,int(185+dx),int(724+oy),BLUE,A,p,r=40)
            L(d,(330+dx,int(738+oy)),"Same invoice as the linehaul",F(44),WHITE,'lm',A*p,im)
            L(d,(330+dx,int(796+oy)),"not a separate favour, chased weeks later",F(30,'700'),MUT,'lm',A*p,im)
    if S(228.0)<=n<S(239.7):
        A,oy=sa(n,228.3,229.1,239.1,239.65)
        if A>0.01:
            ov=Image.new('RGBA',(W,H),(9,15,28,int(255*A))); im.alpha_composite(ov); d=ImageDraw.Draw(im)
            corner_logo(im,A)
            kinetic(im,d,140,int(340+oy),"\"Once the load is off your truck,",54,WHITE,seg(n,S(228.5),S(229.7)))
            kinetic(im,d,140,int(412+oy),"the urgency about making you happy is over.\"",54,ORANGE,seg(n,S(229.6),S(230.9)))
            p=eoc(seg(n,S(233.6),S(234.9)))
            if p>.01:
                card(im,[140,int(580+oy),1780,int(760+oy)],22,alpha=A*p,glow=BLUE if p>.94 else None)
                d2=ImageDraw.Draw(im)
                L(d2,(190,int(640+oy)),"Give the broker ~2 days for an updated rate con",F(42),WHITE,'lm',A*p,im)
                L(d2,(190,int(700+oy)),"then invoice in full anyway — do not wait for permission",F(30,'700'),MUT,'lm',A*p,im)

    # ================= J · WHAT A CORPORATE CHANNEL WON'T TELL YOU  239.46 → 272.63 =================
    if S(239.2)<=n<S(272.9):
        A,oy=sa(n,239.5,240.4,272.2,272.85); corner_logo(im,A)
        kinetic(im,d,140,int(230+oy),"What a corporate channel won't tell you.",56,WHITE,seg(n,S(239.6),S(240.8)))
        B=[("~50%","will pay it","if your paperwork is clean",GREEN,242.6),
           ("~25%","will negotiate","expect to meet in the middle",AMB,246.7),
           ("~25%","will never pay","no matter what you send",RED,251.3)]
        x=140
        for val,l1,l2,col,st in B:
            p=eoc(seg(n,S(st),S(st+1.2)))
            if p>.01:
                card(im,[x,int(370+oy),x+520,int(650+oy)],24,alpha=A*p,glow=col if p>.9 else None)
                d2=ImageDraw.Draw(im)
                L(d2,(x+48,int(448+oy)),val,F(84),col,'lm',A*p,im)
                L(d2,(x+48,int(536+oy)),l1,F(44),WHITE,'lm',A*p,im)
                L(d2,(x+48,int(592+oy)),l2,F(28,'700'),MUT,'lm',A*p,im)
            x+=550
        kinetic(im,d,140,int(740+oy),"That last 25% isn't a paperwork problem. It's a customer problem.",44,WHITE,seg(n,S(255.3),S(256.7)))
        kinetic(im,d,140,int(806+oy),"Quote them higher — or stop hauling for them. Both are legitimate.",38,MUT,seg(n,S(260.2),S(261.6)),'700')
        p9=eoc(seg(n,S(265.5),S(266.9)))
        if p9>.01:
            card(im,[140,int(890+oy),1780,int(1010+oy)],22,alpha=A*p9,glow=ORANGE)
            d2=ImageDraw.Draw(im)
            L(d2,(190,int(950+oy)),"The 75% you can actually win is worth $8,000–$14,000 a year.",F(42,'700'),LT,'lm',A*p9,im)

    # ================= K1 · LOADBOOT  272.63 → 282.7 =================
    if S(272.4)<=n<S(282.9):
        A,oy=sa(n,272.7,273.6,282.3,282.85); corner_logo(im,A)
        kinetic(im,d,140,int(280+oy),"We built the five rules into the load itself.",58,WHITE,seg(n,S(272.8),S(274.0)))
        kinetic(im,d,140,int(348+oy),"Nothing to remember. Nothing to argue.",38,MUT,seg(n,S(274.2),S(275.4)),'700')
        p=eoc(seg(n,S(275.7),S(276.9)))
        if p>.01:
            dx=(1-p)*55
            card(im,[140+dx,int(480+oy),1780+dx,int(660+oy)],22,alpha=A*p,glow=ORANGE if p>.92 else None)
            d=tick(im,d,int(185+dx),int(524+oy),ORANGE,A,p,r=40)
            L(d,(330+dx,int(538+oy)),"Terms on the rate con — before you book",F(44),WHITE,'lm',A*p,im)
            L(d,(330+dx,int(596+oy)),"$60/hr after 2 hours free, printed on every single load",F(30,'700'),MUT,'lm',A*p,im)
        kinetic(im,d,140,int(760+oy),"Not a favour you ask for. A term you already agreed.",40,ORANGE,seg(n,S(279.4),S(280.7)),'700')

    # ================= K2 · PRICING  298.73 → 306.49 =================
    if S(297.9)<=n<S(306.7):
        A,oy=sa(n,298.1,298.9,306.1,306.65); corner_logo(im,A)
        p1=eoc(seg(n,S(298.9),S(300.2)))
        if p1>.01:
            card(im,[140,int(360+oy),1780,int(520+oy)],24,alpha=A*p1,glow=GREEN if p1>.94 else None)
            d2=ImageDraw.Draw(im)
            L(d2,(190,int(422+oy)),"100%",F(72),GREEN,'lm',A*p1,im)
            L(d2,(400,int(430+oy)),"of every accessorial passes through to you",F(40,'700'),WHITE,'lm',A*p1,im)
        p2=eoc(seg(n,S(302.6),S(303.9)))
        if p2>.01:
            card(im,[140,int(560+oy),1780,int(720+oy)],24,alpha=A*p2,glow=ORANGE if p2>.94 else None)
            d2=ImageDraw.Draw(im)
            L(d2,(190,int(622+oy)),"5%",F(72),ORANGE,'lm',A*p2,im)
            L(d2,(340,int(630+oy)),"of the linehaul. Nothing else.",F(40,'700'),WHITE,'lm',A*p2,im)
        kinetic(im,d,140,int(810+oy),"No monthly fee. No per-load fee. No cut of your accessorials.",36,MUT,seg(n,S(304.4),S(305.7)),'700')

    # ================= purpose-built product widgets =================
    # Rule 1, Rule 3 and the whole product section now run on real portal screens
    # (see clips4.SLOTS); the animated clock stays because a live countdown earns its keep.
    if S(166.0)-1<=n<S(176.3)+1: widgets.timer(im,n,166.0,176.3)

    # ================= L · CTA  306.49 → end =================
    if n>=S(306.2):
        a=eoc(seg(n,S(306.5),S(307.6)))
        sc=0.92+0.08*eob(seg(n,S(306.5),S(308.2))); lw=int(600*sc)
        logo_full(im,W//2-lw//2,int(268-(1-a)*40),lw,a)
        kinetic(im,d,W//2,530,"Detention pay that pays.",78,WHITE,seg(n,S(307.1),S(308.3)),'800','mm')
        kinetic(im,d,W//2,614,"Free verified accounts · flat 5% dispatch · $0 monthly",40,MUT,seg(n,S(308.9),S(310.1)),'700','mm')
        p=seg(n,S(312.6),S(313.8)); ac=eoc(p)
        if ac>.01:
            d2=ImageDraw.Draw(im); f=F(56,'800'); tw=d2.textlength("loadboot.com",font=f)
            bw=(tw+120)*(1+0.012*math.sin(n/FPS*3.1))
            card(im,[W//2-bw/2,700,W//2+bw/2,800],50,fill=ORANGE,outline=ORANGE,ow=2,oa=1,alpha=ac,glow=ORANGE)
            L(ImageDraw.Draw(im),(W//2,750),"loadboot.com",f,WHITE,'mm',ac,im)
        kinetic(im,d,W//2,890,"Next: TONU — getting paid when the load cancels.",36,BLUE,seg(n,S(315.0),S(316.3)),'700','mm')
        fo=1-eic(seg(n,S(DUR-1.0),S(DUR)))
        if fo<0.999:
            im.alpha_composite(Image.new('RGBA',(W,H),(0,0,0,int(255*(1-fo)))))

    # ================= product clips (drawn on top) =================
    clips4.render_slot(im,n)
    return im.convert('RGB')

if __name__=='__main__':
    for s in [6,20,30,40,50,66,76,86,96,110,120,131,141,148,158,170,182,192,203,212,219,228,236,244,258,267,276,284,290,296,303,310,316]:
        frame(int(s*FPS)).save(f'/home/user/video/v4_{s}.jpg',quality=86)
    print('v4 test ok')
