"""Animated product clips from real portal screenshots — retimed to the actual voice track."""
import sys, math
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
from render import (F, W, H, FPS, L, card, mix, eoc, eic, seg, NAVY, ORANGE, BLUE, GREEN, WHITE, MUT, LT)
S = lambda s:int(s*FPS)
SH = '/home/user/video/shots/'
_C = {}
PAD = 64
def shot(n):
    """Load the screenshot with an edge-replicated margin, so the ken-burns push-in
    eats the margin instead of trimming real UI (no half-cut buttons or nav labels)."""
    if n not in _C:
        im = Image.open(SH+n+'.png').convert('RGB')
        w,h = im.size; m = PAD
        # left / right / top only — the bottom row is truncated card content and
        # replicating it downward smears visible streaks.
        cv = Image.new('RGB',(w+2*m,h+m))
        cv.paste(im,(m,m))
        cv.paste(im.crop((0,0,1,h)).resize((m,h), Image.NEAREST),(0,m))
        cv.paste(im.crop((w-1,0,w,h)).resize((m,h), Image.NEAREST),(w+m,m))
        cv.paste(cv.crop((0,m,w+2*m,m+1)).resize((w+2*m,m), Image.NEAREST),(0,0))
        _C[n] = cv
    return _C[n]

def draw(im, n, t0, t1, name, caption, sub, focus=None, zoom=(1.00,1.06), anchor_left=True):
    p = (n - S(t0)) / max(1, S(t1)-S(t0))
    fade = min(eoc(seg(n,S(t0),S(t0)+10)), 1-eic(seg(n,S(t1)-10,S(t1))))
    if fade <= 0.01: return
    ov = Image.new('RGBA',(W,H),(5,9,17,int(255*fade))); im.alpha_composite(ov)
    d = ImageDraw.Draw(im)
    # browser frame sized to the shot's aspect so nothing letterboxes
    sw0,sh0 = shot(name).size
    maxw, maxh = 1728, 700
    iw0 = maxw; ih0 = int(maxw*sh0/sw0)
    if ih0 > maxh: ih0 = maxh; iw0 = int(maxh*sw0/sh0)
    fw, fh = iw0+8, ih0+66
    fx0 = (W-fw)//2; fy0 = 168 + max(0,(700-ih0))//2
    fx1, fy1 = fx0+fw, fy0+fh
    card(im,[fx0,fy0,fx1,fy1],16,fill=(13,22,40),outline=BLUE,ow=3,oa=0.42,alpha=fade)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([fx0,fy0,fx1,fy0+54], radius=16, fill=(24,38,64))
    d.rectangle([fx0,fy0+38,fx1,fy0+54], fill=(24,38,64))
    for i,c in enumerate([(248,113,113),(251,191,36),(52,211,153)]):
        d.ellipse([fx0+24+i*28,fy0+20,fx0+37+i*28,fy0+33], fill=c)
    L(d,(fx0+130,fy0+27),"loadboot.com — carrier portal",F(23,'700'),(150,170,205),'lm',fade,im)
    src = shot(name); sw,sh = src.size
    if focus: focus = (focus[0]+PAD, focus[1]+PAD, focus[2]+PAD, focus[3]+PAD)
    z = zoom[0] + (zoom[1]-zoom[0])*eoc(min(1,p*1.15))
    vw,vh = int(sw/z), int(sh/z)
    cx,cy = sw/2, sh/2
    if focus:
        tx,ty = (focus[0]+focus[2])/2, (focus[1]+focus[3])/2
        k = eoc(min(1,p*1.3))*0.42
        cx += (tx-cx)*k; cy += (ty-cy)*k
    x0 = max(0,min(sw-vw,int(cx-vw/2))); y0 = max(0,min(sh-vh,int(cy-vh/2)))
    view = src.crop((x0,y0,x0+vw,y0+vh))
    iw, ih = fx1-fx0-8, fy1-(fy0+58)-8
    scale = min(iw/view.width, ih/view.height)
    view = view.resize((int(view.width*scale), int(view.height*scale)), Image.LANCZOS)
    px = fx0+4+(iw-view.width)//2; py = fy0+58+4+(ih-view.height)//2
    if fade < 0.995:
        lay = view.convert('RGBA'); lay.putalpha(int(255*fade)); im.alpha_composite(lay,(px,py))
    else:
        im.paste(view,(px,py))
    d = ImageDraw.Draw(im)
    if focus:
        hp = eoc(seg(n, S(t0)+int((S(t1)-S(t0))*0.26), S(t0)+int((S(t1)-S(t0))*0.48)))
        if hp > 0.01:
            bx0 = px + int((focus[0]-x0)*scale); by0 = py + int((focus[1]-y0)*scale)
            bx1 = px + int((focus[2]-x0)*scale); by1 = py + int((focus[3]-y0)*scale)
            bx0=max(px,bx0); by0=max(py,by0); bx1=min(px+view.width,bx1); by1=min(py+view.height,by1)
            if bx1>bx0+8 and by1>by0+8:
                lay = Image.new('RGBA',(W,H),(0,0,0,0)); l = ImageDraw.Draw(lay)
                a = int(230*hp*fade)
                pw = 4 + int(2*abs(math.sin(n/FPS*2.4)))
                l.rounded_rectangle([bx0,by0,bx1,by1], radius=10, outline=ORANGE+(a,), width=pw)
                gl = Image.new('RGBA',(W,H),(0,0,0,0)); gd = ImageDraw.Draw(gl)
                gd.rounded_rectangle([bx0-3,by0-3,bx1+3,by1+3], radius=12, outline=ORANGE+(int(120*hp*fade),), width=10)
                lay.alpha_composite(gl.filter(ImageFilter.GaussianBlur(9)))
                im.alpha_composite(lay); d = ImageDraw.Draw(im)
    cp = eoc(seg(n,S(t0)+5,S(t0)+20))
    if cp>0.01:
        f1 = F(40,'800'); tw = d.textlength(caption,font=f1)
        f2 = F(27,'700'); tw2 = d.textlength(sub,font=f2) if sub else 0
        bw = max(tw,tw2)+72
        card(im,[W//2-bw/2,962,W//2+bw/2,962+(96 if sub else 62)],18,
             fill=(13,21,38),outline=ORANGE,ow=2,oa=0.5,alpha=fade*cp)
        d2 = ImageDraw.Draw(im)
        L(d2,(W//2,962+31),caption,f1,WHITE,'mm',fade*cp,im)
        if sub: L(d2,(W//2,962+72),sub,f2,MUT,'mm',fade*cp,im)

# ---- real-screenshot clips, retimed to the voice track (align.json) ----
SLOTS = [
 # RULE 1 — "detention accrues two hours after appointment, seventy-five dollars an hour"
 (125.4,138.4,'p_load',"The terms, before you book",
  "$75/hr after 2 hours free — on the load, not on a phone call",(299,416,1524,498)),
 # RULE 3 — "send it in writing, and keep the timestamp"
 (186.0,198.3,'p_trip_sent',"Sent 15:30:04 — timestamped",
  "in writing, before free time ended",(299,468,1524,568)),
 # LOADBOOT — "your arrival is GPS-stamped at the gate: measured, not argued"
 (282.69,286.78,'dashboard',"GPS-stamped at the gate",
  "measured, not argued — tracking locks on the moment you roll",(310,95,1520,275)),
 # LOADBOOT — "an alert 30 minutes before free time ends, and one tap sends the notice"
 (286.84,293.1,'p_trip_alert',"Alerted 30 minutes before",
  "one tap sends the broker a timestamped notice",(299,468,1524,568)),
 # LOADBOOT — "the claim builds itself with the evidence attached"
 (293.16,298.6,'p_claim',"The claim builds itself",
  "evidence attached, straight onto your invoice",(1069,380,1524,540)),
]
def render_slot(im, n):
    for t0,t1,name,cap,sub,foc in SLOTS:
        if S(t0)-1 <= n < S(t1)+1:
            draw(im,n,t0,t1,name,cap,sub,foc); return True
    return False
