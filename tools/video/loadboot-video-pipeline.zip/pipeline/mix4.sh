#!/bin/bash
# LoadBoot detention explainer — final audio mux.
#  · voice  : edge-tts en-US-AndrewNeural, loudness-normalised to broadcast -16 LUFS
#  · music  : self-synthesised corporate underscore, looped to length, ducked under
#             the voice by a sidechain compressor keyed off the narration itself
set -e
V=/home/user/video/loadboot-detention-FINAL-video.mp4
VO=/home/user/video/voice.mp3
MU=/home/user/music/loadboot-corporate-underscore.mp3
OUT=/home/user/video/loadboot-detention-explainer-FINAL.mp4
DUR=319

ffmpeg -y -hide_banner -loglevel error \
  -i "$V" -i "$VO" -stream_loop -1 -i "$MU" \
  -filter_complex "\
[1:a]aresample=48000,loudnorm=I=-16:TP=-1.5:LRA=11,apad,atrim=0:${DUR},asplit=2[voc][key];\
[2:a]aresample=48000,atrim=0:${DUR},asetpts=N/SR/TB,\
     afade=t=in:st=0:d=2.5,afade=t=out:st=$((DUR-5)):d=5,volume=0.42[mus];\
[mus][key]sidechaincompress=threshold=0.02:ratio=9:attack=8:release=420:makeup=1[musd];\
[voc][musd]amix=inputs=2:duration=first:normalize=0,\
     alimiter=limit=0.97,aresample=48000[aout]" \
  -map 0:v -map "[aout]" -c:v copy -c:a aac -b:a 192k -ar 48000 -ac 2 \
  -movflags +faststart -shortest "$OUT"

echo "--- result ---"
ffprobe -v error -show_entries format=duration,size -of default=nw=1 "$OUT"
ffmpeg -hide_banner -i "$OUT" -af ebur128=framelog=quiet -f null - 2>&1 | tail -12
