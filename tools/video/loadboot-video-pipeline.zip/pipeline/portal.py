"""Real carrier-portal screens.

The sidebar, the header, the nav highlight and the page chrome are lifted pixel-for-pixel
out of the live portal screenshots. Only the CONTENT PANE is redrawn — in the portal's own
card style, sampled from those same screenshots — so each screen shows exactly the thing
the narration is describing, at a size that is legible in video.
"""
import sys, math
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
from render import F, ARROW, ORANGE, GREEN, RED, WHITE

SH   = '/home/user/video/shots/'
SBX  = 275          # sidebar right edge
HDY  = 72           # header bottom
PW,PH = 1548, 674   # portal canvas

# sampled from the live portal
PAGE   = (13, 30, 56)
CARD   = (16, 36, 58)
CARDB  = (34, 68, 98)
BLUE   = (37, 118, 220)
TXT    = (238, 244, 252)
MUT    = (140, 162, 196)
AMB    = (251, 191, 36)

_CH = {}
def _chrome(src):
    if src not in _CH:
        im = Image.open(SH+src+'.png').convert('RGB')
        _CH[src] = im
    return _CH[src]

def screen(src, draw_content):
    """real chrome from `src`, content pane redrawn by draw_content(im, d, box)"""
    base = _chrome(src).convert('RGBA')          # RGBA: ARROW/glow need alpha_composite
    d = ImageDraw.Draw(base)
    # wipe the content pane to the page background (keep sidebar + header)
    d.rectangle([SBX, HDY, PW, PH], fill=PAGE+(255,))
    box = (SBX+24, HDY+22, PW-24, PH-16)
    draw_content(base, ImageDraw.Draw(base), box)
    return base.convert('RGB')

def _card(im, box, r=14, fill=CARD, border=CARDB, bw=2, glow=None):
    d = ImageDraw.Draw(im)
    if glow:
        gl = Image.new('RGBA', (PW, PH), (0,0,0,0))
        ImageDraw.Draw(gl).rounded_rectangle([box[0]-4,box[1]-4,box[2]+4,box[3]+4],
                                             radius=r+4, fill=glow+(52,))
        gl = gl.filter(ImageFilter.GaussianBlur(12))
        im.alpha_composite(gl)
        d = ImageDraw.Draw(im)
    d.rounded_rectangle(list(box), radius=r, fill=fill, outline=border, width=bw)
    return d

def _pill(im, x, y, txt, fg, bg, fs=22):
    d = ImageDraw.Draw(im)
    w = d.textlength(txt, font=F(fs,'800'))
    d.rounded_rectangle([x, y, x+w+30, y+fs+18], radius=(fs+18)//2, fill=bg)
    d.text((x+15, y+(fs+18)//2), txt, font=F(fs,'800'), fill=fg, anchor='lm')
    return x+w+30

def _btn(im, x, y, txt, bg=BLUE, fg=WHITE, fs=26, pad=26):
    d = ImageDraw.Draw(im)
    w = d.textlength(txt, font=F(fs,'800'))
    d.rounded_rectangle([x, y, x+w+pad*2, y+fs+26], radius=10, fill=bg)
    d.text((x+pad+w/2, y+(fs+26)/2), txt, font=F(fs,'800'), fill=fg, anchor='mm')
    return (x, y, x+w+pad*2, y+fs+26)

def _row(im, x, y, w, k, v, vcol=TXT, fs=27):
    d = ImageDraw.Draw(im)
    d.text((x, y), k, font=F(fs,'700'), fill=MUT, anchor='lm')
    d.text((x+w, y), v, font=F(fs+2,'800'), fill=vcol, anchor='rm')

def _tick(im, x, y, col, r=15):
    d = ImageDraw.Draw(im)
    d.ellipse([x, y, x+r*2, y+r*2], fill=col)
    s = r/15.0
    d.line([(x+8*s, y+15*s),(x+13*s, y+21*s),(x+23*s, y+9*s)], fill=WHITE, width=max(2,int(4*s)))

# ══════════════ 1 · LOAD DETAIL — the detention terms, before you book ══════════════
def _c_load(im, d, box):
    x0,y0,x1,_ = box
    _t1 = "LB-10241  ·  Dallas, TX "
    d.text((x0, y0+16), _t1, font=F(34,'800'), fill=TXT, anchor='lm')
    _ax = x0 + d.textlength(_t1, font=F(34,'800'))
    _aw = ARROW(im, d, _ax, y0+16, w=40, col=TXT)
    d.text((_ax+_aw, y0+16), " Atlanta, GA", font=F(34,'800'), fill=TXT, anchor='lm')
    xx = _pill(im, x0, y0+44, "Reefer 53 ft", TXT, (58,40,26))
    xx = _pill(im, xx+10, y0+44, "Solo OK", MUT, (30,40,60))
    _pill(im, xx+10, y0+44, "Terms in writing", (167,243,208), (14,64,52))
    _card(im, (x0, y0+108, x1, y0+256))
    _row(im, x0+28, y0+146, x1-x0-56, "Linehaul", "$2,850.00")
    _row(im, x0+28, y0+192, x1-x0-56, "Miles  ·  rate per mile", "781  ·  $3.65")
    _row(im, x0+28, y0+230, x1-x0-56, "Pickup appointment", "Mon 14:00")
    d.text((x0, y0+300), "ACCESSORIAL TERMS — AGREED BEFORE YOU BOOK", font=F(23,'800'), fill=MUT, anchor='lm')
    _card(im, (x0, y0+322, x1, y0+404), glow=ORANGE)
    d.text((x0+28, y0+352), "Detention", font=F(30,'800'), fill=TXT, anchor='lm')
    d.text((x0+28, y0+384), "accrues 2 hours after appointment", font=F(23,'700'), fill=MUT, anchor='lm')
    d.text((x1-28, y0+366), "$75.00 / hr", font=F(36,'800'), fill=ORANGE, anchor='rm')
    _card(im, (x0, y0+418, x1, y0+474))
    _row(im, x0+28, y0+446, x1-x0-56, "TONU", "$250.00")
    _btn(im, x0, y0+498, "Request this load", ORANGE)
    d.text((x0+300, y0+524), "the rate con is generated with these terms on it",
           font=F(23,'700'), fill=MUT, anchor='lm')

def load_detail(): return screen('loadboard', _c_load)

# ══════════════ 2 · ACTIVE TRIP — the clock, and the one-tap notice ══════════════
def _c_trip(im, d, box, sent=False):
    x0,y0,x1,_ = box
    _card(im, (x0, y0, x1, y0+150), fill=(14,44,86), border=(44,96,170))
    _pill(im, x0+26, y0+22, "ACTIVE TRIP  ·  ON THE ROAD — TRACKING LIVE", (167,243,208), (12,58,44))
    _t2 = "Dallas, TX "
    d.text((x0+26, y0+96), _t2, font=F(36,'800'), fill=TXT, anchor='lm')
    _bx = x0+26 + d.textlength(_t2, font=F(36,'800'))
    _bw = ARROW(im, d, _bx, y0+96, w=42, col=TXT)
    d.text((_bx+_bw, y0+96), " Atlanta, GA", font=F(36,'800'), fill=TXT, anchor='lm')
    d.text((x0+26, y0+130), "$2,850  ·  LB-10241", font=F(24,'700'), fill=(150,190,240), anchor='lm')
    _btn(im, x1-250, y0+52, "Open trip map", ORANGE, fs=24)
    # the detention clock
    _card(im, (x0, y0+172, x1, y0+352), glow=AMB)
    d.text((x0+28, y0+206), "DETENTION CLOCK  ·  DALLAS DISTRIBUTION CENTER",
           font=F(22,'800'), fill=MUT, anchor='lm')
    d.text((x0+28, y0+268), "0:07", font=F(58,'800'), fill=AMB, anchor='lm')
    d.text((x0+178, y0+276), "left of your free time", font=F(27,'700'), fill=TXT, anchor='lm')
    _row(im, x0+700, y0+250, 320, "Arrived (GPS)", "13:52", GREEN, fs=24)
    _row(im, x0+700, y0+292, 320, "Free time ends", "16:00", AMB, fs=24)
    d.text((x0+28, y0+326), "after 16:00 detention accrues at $60/hr — per the rate con",
           font=F(21,'700'), fill=MUT, anchor='lm')
    if not sent:
        _card(im, (x0, y0+374, x1, y0+474), glow=ORANGE)
        d.text((x0+28, y0+408), "Free time ends in 30 minutes", font=F(30,'800'), fill=TXT, anchor='lm')
        d.text((x0+28, y0+444), "send the broker a timestamped notice now — it becomes your evidence",
               font=F(22,'700'), fill=MUT, anchor='lm')
        _btn(im, x1-320, y0+396, "Notify broker", ORANGE, fs=26)
    else:
        _card(im, (x0, y0+374, x1, y0+474), glow=GREEN)
        _tick(im, x0+30, y0+408, GREEN, r=17)
        d.text((x0+84, y0+412), "Notice sent 15:30:04  ·  broker notified in writing",
               font=F(29,'800'), fill=TXT, anchor='lm')
        d.text((x0+84, y0+446), "timestamped by LoadBoot · logged to the load · attached to the claim",
               font=F(22,'700'), fill=MUT, anchor='lm')

def trip_alert():  return screen('dashboard', lambda im,d,b: _c_trip(im,d,b,sent=False))
def trip_sent():   return screen('dashboard', lambda im,d,b: _c_trip(im,d,b,sent=True))

# ══════════════ 3 · THE CLAIM — evidence pack, priced, on the invoice ══════════════
def _c_claim(im, d, box):
    x0,y0,x1,_ = box
    d.text((x0, y0+16), "Detention claim  ·  LB-10241", font=F(34,'800'), fill=TXT, anchor='lm')
    _pill(im, x0, y0+46, "EVIDENCE COMPLETE — 5 OF 5", (167,243,208), (14,64,52))
    ev = [("GPS arrive","13:52"),("GPS depart","17:04"),("Gate photo, timestamped","attached"),
          ("BOL in/out — facility initialled","attached"),("Notice sent before 16:00","15:30:04")]
    yy = y0+112
    for k,v in ev:
        _card(im, (x0, yy, x0+740, yy+56), r=10)
        _tick(im, x0+20, yy+13, GREEN, r=15)
        d.text((x0+70, yy+29), k, font=F(25,'700'), fill=TXT, anchor='lm')
        d.text((x0+720, yy+29), v, font=F(25,'800'), fill=MUT, anchor='rm')
        yy += 66
    _card(im, (x0+770, y0+112, x1, y0+330), glow=AMB)
    _row(im, x0+800, y0+152, x1-x0-830, "On site", "3 h 12 m", TXT, fs=24)
    _row(im, x0+800, y0+192, x1-x0-830, "Free time", "− 2 h 00 m", MUT, fs=24)
    d.line([(x0+800, y0+218),(x1-30, y0+218)], fill=CARDB, width=2)
    _row(im, x0+800, y0+250, x1-x0-830, "Billable  ×  $60/hr", "1 h 04 m", AMB, fs=24)
    d.text((x0+800, y0+300), "DETENTION DUE", font=F(21,'800'), fill=MUT, anchor='lm')
    d.text((x1-30, y0+300), "$64.00", font=F(44,'800'), fill=GREEN, anchor='rm')
    _card(im, (x0+770, y0+346, x1, y0+442), glow=GREEN)
    _tick(im, x0+800, y0+372, GREEN, r=16)
    d.text((x0+846, y0+388), "Added to invoice #10241", font=F(27,'800'), fill=TXT, anchor='lm')
    d.text((x0+800, y0+424), "100% passes through to you", font=F(21,'700'), fill=MUT, anchor='lm')

def claim(): return screen('documents', _c_claim)

# ══════════════ build them out to shots/ ══════════════
if __name__ == '__main__':
    for name, fn in [('p_load', load_detail), ('p_trip_alert', trip_alert),
                     ('p_trip_sent', trip_sent), ('p_claim', claim)]:
        fn().save(SH + name + '.png')
        print('wrote', name)
