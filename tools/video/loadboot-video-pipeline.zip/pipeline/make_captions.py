"""Build YouTube-ready SRT + VTT from the aligned sentence timings.
Long sentences are split into <=2-line cues so they read cleanly on mobile."""
import json, textwrap, re

A = json.load(open('/home/user/video/align.json'))
MAXCHARS = 42          # per line
MAXLINES = 2

def cues():
    out = []
    for s in A['sentences']:
        txt = s['text'].strip()
        st, en = s['start'], s['end']
        lines = textwrap.wrap(txt, MAXCHARS)
        # group into chunks of <=2 lines, time-split proportional to char count
        chunks, cur = [], []
        for ln in lines:
            cur.append(ln)
            if len(cur) == MAXLINES:
                chunks.append(cur); cur = []
        if cur: chunks.append(cur)
        total = sum(len(' '.join(c)) for c in chunks) or 1
        t = st
        for c in chunks:
            share = len(' '.join(c))/total
            d = (en-st)*share
            out.append((t, min(en, t+d), '\n'.join(c)))
            t += d
    return out

def ts(x, comma=True):
    h=int(x//3600); m=int(x%3600//60); s=x%60
    return f"{h:02d}:{m:02d}:{s:06.3f}".replace('.', ',' if comma else '.')

C = cues()
with open('/home/user/video/loadboot-detention-FINAL.srt','w',encoding='utf-8') as f:
    for i,(a,b,t) in enumerate(C,1):
        f.write(f"{i}\n{ts(a)} --> {ts(b)}\n{t}\n\n")
with open('/home/user/video/loadboot-detention-FINAL.vtt','w',encoding='utf-8') as f:
    f.write("WEBVTT\n\n")
    for i,(a,b,t) in enumerate(C,1):
        f.write(f"{i}\n{ts(a,False)} --> {ts(b,False)}\n{t}\n\n")
print(f"{len(C)} cues, last ends {C[-1][1]:.2f}s")
