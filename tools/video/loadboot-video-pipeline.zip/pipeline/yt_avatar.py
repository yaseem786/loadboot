"""YouTube avatar built from the REAL logo asset — icon and wordmark are cropped straight
out of logo-full, so the letterforms and the exact brand colours come along untouched
(white #FFFFFF + orange #F97316). Nothing is retyped or re-coloured."""
import sys
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
from render import LOGO

OUT = '/home/user/video/'
BRAND_ORANGE = (249, 115, 22)      # sampled from the logo itself

# the two pieces of the real lockup
ICON = LOGO.crop((0,   0,  605, 640))     # the mark
WORD = LOGO.crop((856, 0, 2925, 640))     # "LoadBoot" — white + brand orange

def trim(im):
    bb = im.getchannel('A').point(lambda p: 255 if p > 12 else 0).getbbox()
    return im.crop(bb) if bb else im

ICON = trim(ICON); WORD = trim(WORD)

def bg(size):
    """brand navy with a soft off-centre lift, so the mark reads on YouTube's white UI"""
    s = 200
    g = Image.new('RGB', (s, s), (9, 14, 26))
    gd = ImageDraw.Draw(g)
    gd.ellipse([s*0.30-72, s*0.24-72, s*0.30+72, s*0.24+72], fill=(23, 48, 88))
    gd.ellipse([s*0.74-58, s*0.80-58, s*0.74+58, s*0.80+58], fill=(38, 22, 30))
    g = g.filter(ImageFilter.GaussianBlur(20)).resize((size, size), Image.BICUBIC)
    return g.convert('RGBA')

def fit_w(im, w):
    return im.resize((w, max(1, int(im.height*w/im.width))), Image.LANCZOS)

# ─────────────── primary: icon + real wordmark, stacked for the square/circle ───────────────
A = 800
av = bg(A)
ic = fit_w(ICON, 268)                       # ~284 tall
wd = fit_w(WORD, 470)                       # ~145 tall
gap = 34
total = ic.height + gap + wd.height
top = (A - total)//2 - 6                    # nudge up: optical centre sits low with text below
av.alpha_composite(ic, ((A-ic.width)//2, top))
av.alpha_composite(wd, ((A-wd.width)//2, top + ic.height + gap))
av.convert('RGB').save(OUT+'youtube-avatar.png')
print('youtube-avatar.png  800x800  icon + real wordmark')

# circle-crop proof — this is what YouTube actually shows
pf = av.copy()
m = Image.new('L', (A, A), 0)
ImageDraw.Draw(m).ellipse([0, 0, A-1, A-1], fill=255)
out = Image.new('RGB', (A, A), (255, 255, 255))
out.paste(pf.convert('RGB'), (0, 0), m)
d = ImageDraw.Draw(out)
d.ellipse([0, 0, A-1, A-1], outline=(210, 214, 220), width=3)
out.save(OUT+'youtube-avatar-CIRCLE-PROOF.png')
print('youtube-avatar-CIRCLE-PROOF.png  (how it renders, on white)')

# ─────────────── alternate: icon only, for how small YouTube sometimes draws it ───────────────
av2 = bg(A)
ic2 = fit_w(ICON, 430)
av2.alpha_composite(ic2, ((A-ic2.width)//2, (A-ic2.height)//2))
av2.convert('RGB').save(OUT+'youtube-avatar-icon-only.png')
print('youtube-avatar-icon-only.png  800x800  mark only')

# side-by-side at the sizes YouTube really uses
sizes = [136, 88, 48, 24]
strip_w = sum(s+28 for s in sizes)*2 + 60
strip = Image.new('RGB', (strip_w, 210), (255, 255, 255))
sd = ImageDraw.Draw(strip)
x = 30
for src, lab in [(OUT+'youtube-avatar.png','icon + text'), (OUT+'youtube-avatar-icon-only.png','icon only')]:
    base = Image.open(src).convert('RGB')
    for s in sizes:
        th = base.resize((s, s), Image.LANCZOS)
        mm = Image.new('L', (s, s), 0); ImageDraw.Draw(mm).ellipse([0,0,s-1,s-1], fill=255)
        strip.paste(th, (x, 40), mm)
        sd.text((x, 40+s+8), f'{s}px', fill=(90,100,115))
        x += s + 28
    sd.text((x-  (sum(sz+28 for sz in sizes)) , 16), lab, fill=(20,28,42))
    x += 34
strip.save(OUT+'youtube-avatar-SIZE-TEST.png')
print('youtube-avatar-SIZE-TEST.png  (136 / 88 / 48 / 24 px, both versions)')
