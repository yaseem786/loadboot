# LoadBoot video pipeline

Everything needed to render another explainer in the same style, from a script + a voice file.
Pure Python (PIL + numpy) piped into ffmpeg — no editor, no subscriptions, fully reproducible.

## Why this is in the repo

The Cowork container these were built in is ephemeral. Committing the pipeline means the next
session (or a scheduled task) can render video 2 without rebuilding any of it.

## The one thing that cannot run here

**Voice.** Text-to-speech is blocked by the sandbox network policy (gtts, HuggingFace and edge-tts
were all tried — edge-tts gets a hard 403 from the proxy on `speech.platform.bing.com`). So every
video needs `voice.mp3` generated on a Windows PC:

```bat
pip install edge-tts
edge-tts --file script.txt --voice en-US-AndrewNeural --rate=-4%% --write-media voice.mp3
```

Add `--write-subtitles voice.vtt` and you can skip the alignment step below.

## Order of operations

```
1. script.txt                     write the narration, one paragraph per section
2. voice.mp3                      generate on the PC (above), drop it beside these files
3. python3 align.py               -> align.json  (sentence timings recovered from the audio
                                     by silence segmentation, if you have no VTT)
4. edit render4.py                re-time the sections to align.json's sentence table
5. python3 render5.py             writes test stills so you can check before committing
                                     13 minutes of render
6. python3 encode6.py             full render -> loadboot-...-video.mp4   (~13 min, 2 cores)
7. bash post6.sh                  mux voice + ducked music, cut socials, build the 720p web file
8. python3 make_captions.py       -> .srt + .vtt for YouTube and for the on-site player
9. python3 poster.py              -> 1920x1080 poster for the site player
   python3 social_frame.py        -> thumbnail + the 4:5 branded feed frame
```

## What each module does

| File | Role |
|---|---|
| `render.py` | primitives — background, text, cards, logo, easing, the brand palette |
| `motion.py` | the motion-craft layer: mask-wipe text reveals, card drop shadows, push transitions, specular sweeps, the rule progress rail. Patches `render`'s primitives, so **import it before render4** |
| `render4.py` | the timeline. Every section is time-locked to `align.json` |
| `render5.py` | render4 + motion + sweeps + rail. **This is the entry point** |
| `portal.py` | real carrier-portal screens. Sidebar/header/nav lifted pixel-for-pixel from the live screenshots in `shots/`; only the content pane is redrawn, in the portal's own card style, so each screen shows what the narration is describing at a legible size |
| `clips4.py` | Ken Burns + highlight-box treatment over those screens. Screenshots are edge-replicated 64px on left/right/top so the push-in eats margin instead of trimming real UI |
| `widgets.py` / `widgets2.py` | full-screen animated product graphics (live detention clock, alert, claim assembling, rate confirmation, notice log) |
| `yt_brand.py` / `yt_avatar.py` | YouTube banner (safe-area verified) and avatar (cropped from the real logo file) |

## Two rules learned the hard way

1. **Never launch two renders at once.** Both write to the same file and the H.264 stream interleaves
   into garbage that still probes as a valid MP4. Always `pgrep -f encode` first, and always
   `ffmpeg -v error -i out.mp4 -f null -` afterwards to confirm it decodes clean.
2. **Check the VIDEO STREAM, not the container.** `ffprobe -show_entries format=duration` reports the
   *longest* stream, so a video whose picture track is 1 second long still reports 56s because the audio
   is 56s. This actually happened: a `color=...:d=1` source combined with `overlay=...:shortest=1`
   truncated the picture to 25 frames while the audio ran full length, and the container duration hid it.
   Always verify with:
   `ffprobe -v error -select_streams v:0 -count_frames -show_entries stream=nb_read_frames,duration -of default=nw=1 FILE`
   Frames should equal duration x fps.
3. **Every visual must match the sentence being spoken at that moment.** Check with:
   `python3 -c "import json;a=json.load(open('align.json'));[print(s['start'],s['text'][:80]) for s in a['sentences']]"`
   Fitting a spare screenshot into a slot because you happen to have it is how you end up showing a
   load board while the narrator talks about a rate confirmation.

Fonts (`manrope-700.ttf`, `manrope-800.ttf`) must be at `/tmp/fonts/` — `render.py` loads them from
there. Copy them before rendering.
