"""Purpose-built animated product visuals — used where a real screenshot would show
an unpolished or contradictory state. Same design language as the portal."""
import sys, math
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
from render import (F, W, H, FPS, L, card, mix, eoc, eic, eob, seg,
                    NAVY, CARD, ORANGE, BLUE, GREEN, RED, WHITE, MUT, LT, corner_logo)
AMB=(251,191,36); S=lambda s:int(s*FPS)

def _shell(im,n,t0,t1,eyebrow,title):
    """dark overlay + eyebrow/title; returns (draw, alpha) or (None,0)"""
    fade=min(eoc(seg(n,S(t0),S(t0)+10)), 1-eic(seg(n,S(t1)-10,S(t1))))
    if fade<=0.01: return None,0.0
    im.alpha_composite(Image.new('RGBA',(W,H),(5,9,17,int(255*fade))))
    d=ImageDraw.Draw(im); corner_logo(im,fade)
    L(d,(140,206),eyebrow,F(27,'800'),ORANGE,'lm',fade*eoc(seg(n,S(t0)+3,S(t0)+16)),im)
    L(d,(140,268),title,F(54,'800'),WHITE,'lm',fade*eoc(seg(n,S(t0)+6,S(t0)+20)),im)
    return d,fade

def _cap(im,n,t0,fade,caption,sub):
    cp=eoc(seg(n,S(t0)+8,S(t0)+24))
    if cp<=0.01: return
    d=ImageDraw.Draw(im)
    f1=F(40,'800'); f2=F(27,'700')
    bw=max(d.textlength(caption,font=f1), d.textlength(sub,font=f2))+72
    card(im,[W//2-bw/2,962,W//2+bw/2,1058],18,fill=(13,21,38),outline=ORANGE,ow=2,oa=0.5,alpha=fade*cp)
    d2=ImageDraw.Draw(im)
    L(d2,(W//2,993),caption,f1,WHITE,'mm',fade*cp,im)
    L(d2,(W//2,1034),sub,f2,MUT,'mm',fade*cp,im)

def _row(im,d,box,label,value,vcol,A,p,note=None):
    if p<=0.01: return
    dx=(1-p)*46
    card(im,[box[0]+dx,box[1],box[2]+dx,box[3]],18,alpha=A*p)
    d2=ImageDraw.Draw(im)
    cy=(box[1]+box[3])//2
    L(d2,(box[0]+40+dx,cy),label,F(34,'700'),LT,'lm',A*p,im)
    L(d2,(box[2]-40+dx,cy),value,F(44,'800'),vcol,'rm',A*p,im)
    if note: L(d2,(box[2]-40+dx,cy+42),note,F(24,'700'),MUT,'rm',A*p,im)

def _tick(im,x,y,col,a,r=26):
    lay=Image.new('RGBA',(r*2+20,r*2+20),(0,0,0,0)); l=ImageDraw.Draw(lay)
    aa=int(255*a); s=r/26.0
    l.ellipse([10,10,10+r*2,10+r*2],fill=col+(aa,))
    l.line([(10+15*s,10+26*s),(10+24*s,10+35*s),(10+40*s,10+14*s)],fill=WHITE+(aa,),width=max(3,int(7*s)),joint='curve')
    im.alpha_composite(lay,(x,y))

# ─────────────────────────── 1 · DETENTION CLOCK ───────────────────────────
def timer(im,n,t0,t1):
    d,A=_shell(im,n,t0,t1,"THE CLOCK, RUNNING — IN THE APP","Your appointment time. In writing.")
    if not d: return
    L(d,(140,340),"LOAD LB-10241  ·  DALLAS, TX — ATLANTA, GA  ·  $2,850",F(26,'700'),(120,142,180),'lm',A*eoc(seg(n,S(t0)+8,S(t0)+22)),im)
    _row(im,d,[140,390,940,478],"Appointment","14:00",WHITE,A,eoc(seg(n,S(t0)+12,S(t0)+30)))
    p2=eoc(seg(n,S(t0)+26,S(t0)+44))
    _row(im,d,[140,498,940,586],"You arrived","13:52",GREEN,A,p2)
    if p2>0.6:
        pp=eoc(seg(n,S(t0)+40,S(t0)+56))
        _tick(im,690,518,GREEN,A*pp,r=21)
        L(ImageDraw.Draw(im),(140+40,586+34),"GPS-stamped at the gate — 8 minutes early",F(25,'700'),MUT,'lm',A*pp,im)
    _row(im,d,[140,646,940,734],"Free time ends","16:00",AMB,A,eoc(seg(n,S(t0)+48,S(t0)+66)))

    # live countdown panel
    pc=eoc(seg(n,S(t0)+34,S(t0)+52))
    if pc>0.01:
        d=ImageDraw.Draw(im)
        card(im,[1000,390,1780,734],24,alpha=A*pc,glow=AMB if pc>0.93 else None)
        d2=ImageDraw.Draw(im)
        L(d2,(1040,452),"FREE TIME REMAINING",F(27,'800'),MUT,'lm',A*pc,im)
        secs=max(0, 7*60+12 - int((n-S(t0)-34)/FPS*11))
        clock=f"{secs//60}:{secs%60:02d}"
        col=RED if secs<300 else AMB
        L(d2,(1040,566),clock,F(150,'800'),col,'lm',A*pc,im)
        # progress bar of the 2-hour free window
        used=1-(secs/(2*3600))
        lay=Image.new('RGBA',(W,H),(0,0,0,0)); l=ImageDraw.Draw(lay)
        l.rounded_rectangle([1040,652,1740,684],radius=16,fill=mix(col,CARD,.22)+(int(255*A*pc),))
        l.rounded_rectangle([1040,652,1040+int(700*used),684],radius=16,fill=col+(int(255*A*pc),))
        im.alpha_composite(lay); d2=ImageDraw.Draw(im)
        L(d2,(1040,712),"after 16:00 detention accrues at $60/hr — printed on the rate con",F(24,'700'),MUT,'lm',A*pc,im)
    _cap(im,n,t0,A,"The appointment time, in writing",
         "free time starts when you were due — not when they get to you")

# ─────────────────────────── 2 · THE 30-MINUTE ALERT ───────────────────────────
def alertw(im,n,t0,t1):
    d,A=_shell(im,n,t0,t1,"30 MINUTES BEFORE THE CLOCK RUNS OUT","You get told. Then it's one tap.")
    if not d: return
    # notification toast slides in
    p1=eoc(seg(n,S(t0)+10,S(t0)+28))
    if p1>0.01:
        dy=int((1-p1)*-70)
        card(im,[300,int(370+dy),1620,int(560+dy)],24,alpha=A*p1,outline=AMB,ow=3,oa=0.7,
             glow=AMB if p1>0.93 else None)
        d2=ImageDraw.Draw(im)
        # clock face — unambiguous, and it ties to the countdown
        bl=Image.new('RGBA',(120,120),(0,0,0,0)); b=ImageDraw.Draw(bl); aa=int(255*A*p1)
        b.ellipse([16,16,104,104],fill=AMB+(aa,))
        b.ellipse([27,27,93,93],outline=NAVY+(aa,),width=5)
        b.line([(60,60),(60,38)],fill=NAVY+(aa,),width=7)      # minute hand
        b.line([(60,60),(78,68)],fill=NAVY+(aa,),width=7)      # hour hand
        b.ellipse([55,55,65,65],fill=NAVY+(aa,))
        im.alpha_composite(bl,(346,int(400+dy))); d2=ImageDraw.Draw(im)
        L(d2,(500,int(432+dy)),"Free time ends in 30 minutes",F(44,'800'),WHITE,'lm',A*p1,im)
        L(d2,(500,int(486+dy)),"Dallas Distribution Center  ·  appointment 14:00  ·  free until 16:00",F(28,'700'),MUT,'lm',A*p1,im)
        L(d2,(1570,int(432+dy)),"15:30",F(34,'800'),AMB,'rm',A*p1,im)

    # one-tap button
    p2=eoc(seg(n,S(t0)+32,S(t0)+50))
    if p2>0.01:
        pu=1+0.016*math.sin(n/FPS*3.4)
        bw=760*pu
        card(im,[W//2-bw/2,620,W//2+bw/2,730],55,fill=ORANGE,outline=ORANGE,ow=2,oa=1,
             alpha=A*p2,glow=ORANGE)
        L(ImageDraw.Draw(im),(W//2,675),"Notify broker  —  1 tap",F(46,'800'),WHITE,'mm',A*p2,im)

    # sent stamp
    p3=eoc(seg(n,S(t0)+58,S(t0)+76))
    if p3>0.01:
        card(im,[380,790,1540,900],22,alpha=A*p3,outline=GREEN,ow=2,oa=0.65,
             glow=GREEN if p3>0.93 else None)
        _tick(im,424,818,GREEN,A*p3,r=26)
        d2=ImageDraw.Draw(im)
        L(d2,(510,832),"Notice sent 15:30:04  ·  broker notified in writing",F(36,'800'),WHITE,'lm',A*p3,im)
        L(d2,(510,876),"timestamped, logged to the load, and attached to the claim",F(25,'700'),MUT,'lm',A*p3,im)
    _cap(im,n,t0,A,"Alerted before the clock runs out",
         "30 minutes' warning — one tap sends the timestamped notice")

# ─────────────────────────── 3 · THE CLAIM BUILDS ITSELF ───────────────────────────
def claimw(im,n,t0,t1):
    d,A=_shell(im,n,t0,t1,"DETENTION CLAIM  ·  LB-10241","Then the claim builds itself.")
    if not d: return
    ev=[("GPS arrive",            "13:52",  4),
        ("GPS depart",            "17:04", 12),
        ("Gate photo, timestamped","attached", 20),
        ("BOL in/out — initialled","attached", 28),
        ("Notice sent before 16:00","15:30:04",36)]
    yy=336
    for lbl,val,off in ev:
        p=eoc(seg(n,S(t0)+off+8,S(t0)+off+20))
        if p>0.01:
            dx=(1-p)*40
            card(im,[140+dx,yy,1180+dx,yy+76],16,alpha=A*p)
            _tick(im,int(168+dx),yy+12,GREEN,A*p,r=23)
            d2=ImageDraw.Draw(im)
            L(d2,(258+dx,yy+39),lbl,F(32,'700'),LT,'lm',A*p,im)
            L(d2,(1140+dx,yy+39),val,F(32,'800'),WHITE,'rm',A*p,im)
        yy+=88

    # the maths panel
    pm=eoc(seg(n,S(t0)+52,S(t0)+70))
    if pm>0.01:
        card(im,[1230,336,1780,660],24,alpha=A*pm,glow=AMB if pm>0.93 else None)
        d2=ImageDraw.Draw(im)
        L(d2,(1270,390),"ON SITE",F(24,'800'),MUT,'lm',A*pm,im)
        L(d2,(1740,390),"3 h 12 m",F(36,'800'),WHITE,'rm',A*pm,im)
        L(d2,(1270,454),"FREE TIME",F(24,'800'),MUT,'lm',A*pm,im)
        L(d2,(1740,454),"− 2 h 00 m",F(36,'800'),MUT,'rm',A*pm,im)
        d2.line([(1270,496),(1740,496)],fill=(60,80,116),width=2)
        L(d2,(1270,542),"BILLABLE",F(24,'800'),AMB,'lm',A*pm,im)
        L(d2,(1740,542),"1 h 04 m",F(36,'800'),AMB,'rm',A*pm,im)
        L(d2,(1270,606),"× $60 / hr",F(26,'700'),MUT,'lm',A*pm,im)
        L(d2,(1740,614),"$64.00",F(56,'800'),GREEN,'rm',A*pm,im)

    # lands on the invoice
    pi=eoc(seg(n,S(t0)+76,S(t0)+94))
    if pi>0.01:
        card(im,[140,800,1780,916],22,alpha=A*pi,outline=GREEN,ow=2,oa=0.7,glow=GREEN)
        _tick(im,186,830,GREEN,A*pi,r=28)
        d2=ImageDraw.Draw(im)
        L(d2,(280,842),"$64.00 detention added to invoice #10241",F(40,'800'),WHITE,'lm',A*pi,im)
        L(d2,(280,888),"evidence attached  ·  nothing to chase  ·  100% passes through to you",F(25,'700'),MUT,'lm',A*pi,im)
    _cap(im,n,t0,A,"The claim builds itself",
         "evidence attached, straight onto your invoice")
