"""Forced-ish alignment: map script sentences -> real timestamps in voice.mp3
using silence segmentation + proportional char-length fill inside each speech run."""
import subprocess, re, json, sys

VOICE = '/home/user/video/voice.mp3'
SCRIPT = '/mnt/user-data/uploads/Downloads/voice-kit/script.txt'

def silences(noise='-40dB', d=0.30):
    out = subprocess.run(['ffmpeg','-hide_banner','-i',VOICE,'-af',
        f'silencedetect=noise={noise}:d={d}','-f','null','-'],
        capture_output=True, text=True).stderr
    dur = float(subprocess.run(['ffprobe','-v','error','-show_entries','format=duration',
        '-of','csv=p=0',VOICE],capture_output=True,text=True).stdout.strip())
    st = [float(x) for x in re.findall(r'silence_start: ([0-9.]+)', out)]
    en = [float(x) for x in re.findall(r'silence_end: ([0-9.]+)', out)]
    return list(zip(st,en)), dur

def speech_runs(sil, dur):
    runs = []; cur = 0.0
    for s,e in sil:
        if s - cur > 0.12: runs.append((cur, s))
        cur = e
    if dur - cur > 0.12: runs.append((cur, dur))
    return runs

# --- sentences from script (paragraph aware) ---
raw = open(SCRIPT, encoding='utf-8').read()
paras = [p.strip() for p in raw.split('\n\n') if p.strip()]
sents = []   # (para_idx, text)
for pi, p in enumerate(paras):
    parts = re.split(r'(?<=[.!?])\s+(?=[A-Z0-9])', p)
    for s in parts:
        s = s.strip()
        if s: sents.append((pi, s))

sil, dur = silences()
runs = speech_runs(sil, dur)
print(f'audio {dur:.2f}s  |  {len(runs)} speech runs  |  {len(sents)} sentences', file=sys.stderr)

# Greedy: distribute sentences across runs weighted by total char length.
tot_chars = sum(len(s) for _, s in sents)
tot_speech = sum(b-a for a,b in runs)
# walk runs, filling sentences by char budget
timing = []      # (start, end, para_idx, text)
ri = 0
run_start, run_end = runs[0]
pos = run_start
for pi, s in sents:
    need = len(s)/tot_chars * tot_speech
    got = 0.0; st = pos;
    while got < need - 1e-6:
        avail = run_end - pos
        if avail <= 1e-6:
            ri += 1
            if ri >= len(runs): break
            run_start, run_end = runs[ri]; pos = run_start
            continue
        take = min(avail, need-got)
        pos += take; got += take
    timing.append((st, pos, pi, s))

# paragraph-level anchors (what the video timeline needs)
pstart = {}; pend = {}
for st, en, pi, s in timing:
    pstart.setdefault(pi, st); pend[pi] = en

anchors = [(pi, round(pstart[pi],2), round(pend[pi],2), paras[pi][:70]) for pi in sorted(pstart)]
json.dump({'duration': dur,
           'paragraphs': [{'i':a[0],'start':a[1],'end':a[2],'head':a[3]} for a in anchors],
           'sentences': [{'start':round(a,2),'end':round(b,2),'para':c,'text':d} for a,b,c,d in timing]},
          open('/home/user/video/align.json','w'), indent=1)
for a in anchors: print(f'P{a[0]:>2}  {a[1]:>7.2f} -> {a[2]:>7.2f}   {a[3]}')
