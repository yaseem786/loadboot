"""Two product visuals built FROM the narration (not fitted to a spare screenshot):
   · ratecon()   — the detention clause on the rate confirmation, signed back
   · noticelog() — the timestamped notice that becomes the contemporaneous record
"""
import sys, math
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
from render import (F, W, H, FPS, L, card, mix, eoc, eic, eob, seg,
                    NAVY, CARD, ORANGE, BLUE, GREEN, RED, WHITE, MUT, LT, corner_logo)
AMB=(251,191,36); S=lambda s:int(s*FPS)
PAPER=(238,242,248); INK=(15,23,42); INK2=(71,85,105); RULE=(203,213,225)

def _shell(im,n,t0,t1,eyebrow,title):
    fade=min(eoc(seg(n,S(t0),S(t0)+10)), 1-eic(seg(n,S(t1)-10,S(t1))))
    if fade<=0.01: return None,0.0
    im.alpha_composite(Image.new('RGBA',(W,H),(5,9,17,int(255*fade))))
    d=ImageDraw.Draw(im); corner_logo(im,fade)
    L(d,(140,200),eyebrow,F(27,'800'),ORANGE,'lm',fade*eoc(seg(n,S(t0)+3,S(t0)+16)),im)
    L(d,(140,260),title,F(52,'800'),WHITE,'lm',fade*eoc(seg(n,S(t0)+6,S(t0)+20)),im)
    return d,fade

def _cap(im,n,t0,fade,caption,sub):
    cp=eoc(seg(n,S(t0)+8,S(t0)+24))
    if cp<=0.01: return
    d=ImageDraw.Draw(im); f1=F(40,'800'); f2=F(27,'700')
    bw=max(d.textlength(caption,font=f1), d.textlength(sub,font=f2))+72
    card(im,[W//2-bw/2,962,W//2+bw/2,1058],18,fill=(13,21,38),outline=ORANGE,ow=2,oa=0.5,alpha=fade*cp)
    d2=ImageDraw.Draw(im)
    L(d2,(W//2,993),caption,f1,WHITE,'mm',fade*cp,im)
    L(d2,(W//2,1034),sub,f2,MUT,'mm',fade*cp,im)

def _tick(im,x,y,col,a,r=24):
    lay=Image.new('RGBA',(r*2+20,r*2+20),(0,0,0,0)); l=ImageDraw.Draw(lay)
    aa=int(255*a); s=r/26.0
    l.ellipse([10,10,10+r*2,10+r*2],fill=col+(aa,))
    l.line([(10+15*s,10+26*s),(10+24*s,10+35*s),(10+40*s,10+14*s)],fill=WHITE+(aa,),width=max(3,int(7*s)),joint='curve')
    im.alpha_composite(lay,(x,y))

# ───────────────── 1 · THE RATE CONFIRMATION (Rule 1, ~125.4–138.4) ─────────────────
def ratecon(im,n,t0,t1):
    d,A=_shell(im,n,t0,t1,"ON THE RATE CONFIRMATION — BEFORE YOU BOOK",
               "Not promised on the phone. Printed.")
    if not d: return
    p0=eoc(seg(n,S(t0)+8,S(t0)+24))
    if p0<=0.01:
        _cap(im,n,t0,A,"Written into the rate con","and signed back to you — before the wheels turn"); return
    # the document
    DX,DY,DW,DH = 150,340,1080,600
    lay=Image.new('RGBA',(W,H),(0,0,0,0)); l=ImageDraw.Draw(lay)
    aa=int(255*A*p0)
    l.rounded_rectangle([DX,DY,DX+DW,DY+DH],radius=10,fill=PAPER+(aa,))
    im.alpha_composite(lay); d=ImageDraw.Draw(im)
    L(d,(DX+40,DY+56),"RATE CONFIRMATION",F(34,'800'),INK,'lm',A*p0,im)
    L(d,(DX+DW-40,DY+56),"LB-10241",F(30,'800'),INK2,'rm',A*p0,im)
    L(d,(DX+40,DY+96),"Midwest Freight Brokers LLC  ·  MC 812446",F(23,'700'),INK2,'lm',A*p0,im)
    d.line([(DX+40,DY+126),(DX+DW-40,DY+126)],fill=RULE,width=2)
    rows=[("Linehaul","$2,850.00",10),("Miles","781",16),("Equipment","Reefer 53 ft",22),
          ("Pickup appointment","Mon 14:00 — Dallas, TX",28)]
    yy=DY+170
    for k,v,off in rows:
        p=eoc(seg(n,S(t0)+off+8,S(t0)+off+20))
        if p>0.01:
            L(d,(DX+40,yy),k,F(26,'700'),INK2,'lm',A*p,im)
            L(d,(DX+DW-40,yy),v,F(28,'800'),INK,'rm',A*p,im)
        yy+=48
    pa=eoc(seg(n,S(t0)+40,S(t0)+54))
    if pa>0.01:
        L(d,(DX+40,DY+382),"ACCESSORIALS",F(23,'800'),INK2,'lm',A*pa,im)
        d.line([(DX+40,DY+404),(DX+DW-40,DY+404)],fill=RULE,width=2)
    # the detention line — the thing being narrated
    pdl=eoc(seg(n,S(t0)+52,S(t0)+68))
    if pdl>0.01:
        L(d,(DX+62,DY+452),"DETENTION",F(30,'800'),INK,'lm',A*pdl,im)
        L(d,(DX+62,DY+488),"accrues 2 hours after appointment",F(24,'700'),INK2,'lm',A*pdl,im)
        L(d,(DX+DW-62,DY+466),"$75.00 / hr",F(38,'800'),(197,48,48),'rm',A*pdl,im)
    ph=eoc(seg(n,S(t0)+66,S(t0)+86))
    if ph>0.01:
        bx=[DX+44,DY+428,DX+DW-44,DY+512]
        gl=Image.new('RGBA',(W,H),(0,0,0,0)); g=ImageDraw.Draw(gl)
        pw=4+int(2*abs(math.sin(n/FPS*2.6)))
        g.rounded_rectangle(bx,radius=8,outline=ORANGE+(int(235*ph*A),),width=pw)
        g2=Image.new('RGBA',(W,H),(0,0,0,0)); ImageDraw.Draw(g2).rounded_rectangle(
            [bx[0]-3,bx[1]-3,bx[2]+3,bx[3]+3],radius=10,outline=ORANGE+(int(120*ph*A),),width=10)
        gl.alpha_composite(g2.filter(ImageFilter.GaussianBlur(9)))
        im.alpha_composite(gl); d=ImageDraw.Draw(im)
    pt=eoc(seg(n,S(t0)+80,S(t0)+96))
    if pt>0.01:
        L(d,(DX+40,DY+556),"TONU",F(26,'700'),INK2,'lm',A*pt,im)
        L(d,(DX+DW-40,DY+556),"$250.00",F(28,'800'),INK,'rm',A*pt,im)

    # right rail: what makes it binding
    notes=[("It is on the document","not a text, not a phone call",108),
           ("A number and a trigger","$75/hr, 2 hrs after appointment",124),
           ("Signed back by the broker","returned 08:41, before dispatch",140)]
    yy=372
    for k,v,off in notes:
        p=eoc(seg(n,S(t0)+off,S(t0)+off+16))
        if p>0.01:
            dx=(1-p)*40
            card(im,[1280+dx,yy,1790+dx,yy+150],20,alpha=A*p,glow=GREEN if p>0.95 else None)
            _tick(im,int(1310+dx),yy+24,GREEN,A*p,r=22)
            d2=ImageDraw.Draw(im)
            L(d2,(1310+dx,yy+98),k,F(30,'800'),WHITE,'lm',A*p,im)
            L(d2,(1310+dx,yy+132),v,F(22,'700'),MUT,'lm',A*p,im)
        yy+=170
    _cap(im,n,t0,A,"Written into the rate con","and signed back to you — before the wheels turn")

# ───────────────── 2 · THE NOTICE / THE RECORD (Rule 3, ~186.0–198.3) ─────────────────
def noticelog(im,n,t0,t1):
    d,A=_shell(im,n,t0,t1,"THE RECORD, MADE WHILE IT WAS HAPPENING",
               "This is what a broker cannot argue with.")
    if not d: return
    p0=eoc(seg(n,S(t0)+8,S(t0)+26))
    if p0>0.01:
        card(im,[150,340,1180,700],20,alpha=A*p0,outline=BLUE,ow=2,oa=0.5)
        d2=ImageDraw.Draw(im)
        L(d2,(190,388),"DETENTION NOTICE  ·  SENT",F(23,'800'),BLUE,'lm',A*p0,im)
        L(d2,(1140,388),"15:30:04",F(30,'800'),GREEN,'rm',A*p0,im)
        d2.line([(190,414),(1140,414)],fill=(52,70,104),width=2)
        L(d2,(190,452),"To:  Midwest Freight Brokers  ·  dispatch@midwestfb.com",F(24,'700'),MUT,'lm',A*p0,im)
        lines=[("Load LB-10241 — Dallas Distribution Center.",30),
               ("Truck on site since 13:52 (GPS-stamped at the gate).",44),
               ("Appointment 14:00. Free time ends 16:00.",58),
               ("Detention will accrue at $60/hr per the rate confirmation.",72)]
        yy=512
        for t,off in lines:
            p=eoc(seg(n,S(t0)+off,S(t0)+off+16))
            if p>0.01:
                L(ImageDraw.Draw(im),(190,yy),t,F(28,'700'),WHITE,'lm',A*p,im)
            yy+=46
    # why it holds up
    facts=[("Sent before free time ended","30 minutes before, not after",GREEN,88),
           ("Timestamped by the platform","not by you, not by the broker",BLUE,104),
           ("Attached to the load","and to the claim, automatically",AMB,120)]
    yy=372
    for k,v,col,off in facts:
        p=eoc(seg(n,S(t0)+off,S(t0)+off+16))
        if p>0.01:
            dx=(1-p)*44
            card(im,[1240+dx,yy,1790+dx,yy+150],20,alpha=A*p,glow=col if p>0.95 else None)
            _tick(im,int(1272+dx),yy+24,col,A*p,r=22)
            d2=ImageDraw.Draw(im)
            L(d2,(1272+dx,yy+98),k,F(29,'800'),WHITE,'lm',A*p,im)
            L(d2,(1272+dx,yy+132),v,F(22,'700'),MUT,'lm',A*p,im)
        yy+=170
    pf=eoc(seg(n,S(t0)+138,S(t0)+156))
    if pf>0.01:
        card(im,[150,742,1180,858],20,alpha=A*pf,outline=ORANGE,ow=2,oa=0.6,glow=ORANGE)
        d2=ImageDraw.Draw(im)
        L(d2,(190,788),"Hour 1:45 is evidence.",F(34,'800'),WHITE,'lm',A*pf,im)
        L(d2,(190,830),"The same message at hour 5 is a complaint.",F(29,'700'),MUT,'lm',A*pf,im)
    _cap(im,n,t0,A,"In writing, before the clock ran out",
         "timestamped by the platform — not by either party")
