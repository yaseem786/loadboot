"""Branded 4:5 feed frame (transparent window where the video sits) + YouTube thumbnail."""
import sys
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw
from render import F, L, card, logo_full, ORANGE, WHITE, MUT, LT, RED, GREEN

# ---------------- 4:5 feed frame: 1080x1350, video window at y 371..979 ----------------
W,H = 1080,1350
im = Image.new('RGBA',(W,H),(7,11,20,255))
d  = ImageDraw.Draw(im)
# top band
L(d,(60,96),"DETENTION PAY",F(34,'800'),ORANGE,'lm',1.0,im)
L(d,(60,178),"Fewer than half of billed",F(58,'800'),WHITE,'lm',1.0,im)
L(d,(60,246),"detention is ever paid.",F(58,'800'),WHITE,'lm',1.0,im)
L(d,(60,318),"Here are the 5 rules that get it paid.",F(33,'700'),MUT,'lm',1.0,im)
# hairline above/below the video window
d.rectangle([0,366,W,370], fill=(255,92,26,255))
d.rectangle([0,980,W,984], fill=(255,92,26,255))
# bottom band
L(d,(60,1046),"$60/hr after 2 hours free  ·  printed on every load",F(31,'700'),LT,'lm',1.0,im)
L(d,(60,1102),"GPS-stamped arrival  ·  the claim builds itself",F(31,'700'),LT,'lm',1.0,im)
card(im,[60,1160,470,1268],54,fill=ORANGE,outline=ORANGE,ow=2,oa=1,alpha=1.0)
L(ImageDraw.Draw(im),(265,1214),"loadboot.com",F(40,'800'),WHITE,'mm',1.0,im)
logo_full(im, 700, 1178, 300, 1.0)
# punch the video window transparent so the overlay only paints the bands
for y in range(371,980):
    for x in range(0,W,1):
        pass
im.paste((0,0,0,0),(0,371,W,980))
im.save('/home/user/video/social_45_frame.png')
print('4:5 frame ok')

# ---------------- YouTube thumbnail 1280x720 ----------------
TW,TH = 1280,720
t = Image.new('RGBA',(TW,TH),(7,11,20,255))
td = ImageDraw.Draw(t)
# left: the number that stops the scroll
L(td,(64,120),"THEY WAITED.",F(40,'800'),MUT,'lm',1.0,t)
L(td,(64,208),"17%",F(178,'800'),RED,'lm',1.0,t)
L(td,(64,318),"NEVER GET PAID",F(52,'800'),WHITE,'lm',1.0,t)
L(td,(64,382),"A DOLLAR OF DETENTION",F(52,'800'),WHITE,'lm',1.0,t)
card(t,[64,452,660,548],20,alpha=1.0,glow=ORANGE)
L(ImageDraw.Draw(t),(92,500),"The 5 rules that fix it",F(42,'800'),ORANGE,'lm',1.0,t)
L(ImageDraw.Draw(t),(64,606),"ATRI · DAT · OOIDA · DOT OIG",F(24,'700'),(104,124,160),'lm',1.0,t)
logo_full(t, 64, 636, 250, 1.0)
# right: the money panel
card(t,[740,150,1216,570],26,alpha=1.0,glow=RED)
d2=ImageDraw.Draw(t)
L(d2,(780,214),"DETENTION BILLS AT",F(24,'800'),MUT,'lm',1.0,t)
L(d2,(780,278),"$63.00/hr",F(64,'800'),(96,165,250),'lm',1.0,t)
L(d2,(780,354),"AN HOUR OF TRUCK COSTS",F(24,'800'),MUT,'lm',1.0,t)
L(d2,(780,418),"$66.65/hr",F(64,'800'),RED,'lm',1.0,t)
d2.line([(780,466),(1176,466)],fill=(60,80,116),width=3)
L(d2,(780,516),"you are $3.65/hr underwater",F(30,'800'),ORANGE,'lm',1.0,t)
t.convert('RGB').save('/home/user/video/loadboot-detention-thumbnail.jpg',quality=93)
print('thumbnail ok')
