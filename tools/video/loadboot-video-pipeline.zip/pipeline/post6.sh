#!/bin/bash
# Everything after the v2 video render: audio mux, integrity check, social cuts, web build.
set -e
D=/home/user/video
V=$D/loadboot-detention-v3-video.mp4
VO=$D/voice.mp3
MU=/home/user/music/loadboot-corporate-underscore.mp3
M=$D/loadboot-detention-explainer-v3-FINAL.mp4
DUR=319

[ -f "$V" ] || { echo "v2 video missing"; exit 1; }
echo "== integrity of the raw render =="
ffmpeg -v error -i "$V" -f null - 2>&1 | head -3
echo "(empty above = clean)"

echo "== mux voice + ducked music =="
ffmpeg -y -hide_banner -loglevel error \
  -i "$V" -i "$VO" -stream_loop -1 -i "$MU" \
  -filter_complex "\
[1:a]aresample=48000,loudnorm=I=-16:TP=-1.5:LRA=11,apad,atrim=0:${DUR},asplit=2[voc][key];\
[2:a]aresample=48000,atrim=0:${DUR},asetpts=N/SR/TB,\
     afade=t=in:st=0:d=2.5,afade=t=out:st=$((DUR-5)):d=5,volume=0.42[mus];\
[mus][key]sidechaincompress=threshold=0.02:ratio=9:attack=8:release=420:makeup=1[musd];\
[voc][musd]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.97,aresample=48000[aout]" \
  -map 0:v -map "[aout]" -c:v copy -c:a aac -b:a 192k -ar 48000 -ac 2 \
  -movflags +faststart -shortest "$M"

echo "== social cuts =="
seg () { ffmpeg -y -hide_banner -loglevel error -ss "$2" -to "$3" -i "$M" \
  -c:v libx264 -preset medium -crf 19 -pix_fmt yuv420p -c:a aac -b:a 192k -ar 48000 -ac 2 \
  -avoid_negative_ts make_zero "$D/_t$1.mp4"; }
seg A 0.00   8.75
seg B 82.95  108.05
seg C 272.63 286.78
seg D 306.49 316.20
ffmpeg -y -hide_banner -loglevel error \
 -i "$D/_tA.mp4" -i "$D/_tB.mp4" -i "$D/_tC.mp4" -i "$D/_tD.mp4" \
 -filter_complex "\
[0:v][1:v]xfade=transition=fade:duration=0.4:offset=8.35[v1];\
[v1][2:v]xfade=transition=fade:duration=0.4:offset=33.05[v2];\
[v2][3:v]xfade=transition=fade:duration=0.4:offset=46.83[vv];\
[0:a][1:a]acrossfade=d=0.4:c1=tri:c2=tri[a1];\
[a1][2:a]acrossfade=d=0.4:c1=tri:c2=tri[a2];\
[a2][3:a]acrossfade=d=0.4:c1=tri:c2=tri[aa]" \
 -map "[vv]" -map "[aa]" -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \
 -c:a aac -b:a 192k -movflags +faststart "$D/loadboot-detention-v3-teaser-56s.mp4"

ffmpeg -y -hide_banner -loglevel error \
 -i "$D/loadboot-detention-v3-teaser-56s.mp4" -i "$D/social_45_frame.png" \
 -filter_complex "[0:v]scale=1080:608:flags=lanczos[vid];[1:v]format=rgba[fr];\
color=c=0x070B14:s=1080x1350:r=30[bgc];\
[bgc][vid]overlay=0:371:shortest=1[b1];[b1][fr]overlay=0:0[vo]" \
 -map "[vo]" -map 0:a -c:v libx264 -preset slow -crf 20 -pix_fmt yuv420p \
 -c:a aac -b:a 160k -movflags +faststart "$D/loadboot-detention-v3-teaser-4x5.mp4"

echo "== 720p web version for the site =="
ffmpeg -y -hide_banner -loglevel error -i "$M" \
 -vf scale=1280:720:flags=lanczos -c:v libx264 -preset slow -crf 25 -pix_fmt yuv420p \
 -c:a aac -b:a 128k -movflags +faststart "$D/loadboot-detention-explainer.mp4"

rm -f "$D"/_t[ABCD].mp4
echo "== outputs =="
for f in loadboot-detention-explainer-v3-FINAL.mp4 loadboot-detention-v3-teaser-56s.mp4 \
         loadboot-detention-v3-teaser-4x5.mp4 loadboot-detention-explainer.mp4; do
  printf '%-48s ' "$f"; ffprobe -v error -show_entries format=duration,size -of csv=p=0 "$D/$f"
done
echo "== final decode check =="
ffmpeg -v error -i "$M" -f null - 2>&1 | head -3
echo "(empty above = clean)"
