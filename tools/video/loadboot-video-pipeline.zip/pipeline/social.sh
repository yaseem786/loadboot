#!/bin/bash
# Social cuts from the finished master. No re-render — real cuts with crossfades.
set -e
M=/home/user/video/loadboot-detention-explainer-FINAL.mp4
D=/home/user/video
[ -f "$M" ] || { echo "master not found: $M"; exit 1; }

# ── segments chosen so the narration is self-contained in each ──
#  A 0.00–8.75    the hook (17% never paid — they couldn't prove it)
#  B 82.95–108.05 the part nobody says out loud ($63 vs $66.65 → $3.65 underwater)
#  C 272.63–286.78 how LoadBoot does it (+ the real dashboard/GPS clip)
#  D 306.49–316.20 the CTA
seg () { ffmpeg -y -hide_banner -loglevel error -ss "$2" -to "$3" -i "$M" \
  -c:v libx264 -preset medium -crf 19 -pix_fmt yuv420p -c:a aac -b:a 192k -ar 48000 -ac 2 \
  -avoid_negative_ts make_zero "$D/_s$1.mp4"; }
seg A 0.00   8.75
seg B 82.95  108.05
seg C 272.63 286.78
seg D 306.49 316.20

# crossfade the four together (0.4s), video + audio
ffmpeg -y -hide_banner -loglevel error \
 -i "$D/_sA.mp4" -i "$D/_sB.mp4" -i "$D/_sC.mp4" -i "$D/_sD.mp4" \
 -filter_complex "\
[0:v][1:v]xfade=transition=fade:duration=0.4:offset=8.35[v1];\
[v1][2:v]xfade=transition=fade:duration=0.4:offset=33.05[v2];\
[v2][3:v]xfade=transition=fade:duration=0.4:offset=46.83[vv];\
[0:a][1:a]acrossfade=d=0.4:c1=tri:c2=tri[a1];\
[a1][2:a]acrossfade=d=0.4:c1=tri:c2=tri[a2];\
[a2][3:a]acrossfade=d=0.4:c1=tri:c2=tri[aa]" \
 -map "[vv]" -map "[aa]" -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \
 -c:a aac -b:a 192k -movflags +faststart "$D/loadboot-detention-teaser-56s.mp4"

# ── 4:5 feed version (1080x1350) — branded bars top & bottom ──
ffmpeg -y -hide_banner -loglevel error \
 -i "$D/loadboot-detention-teaser-56s.mp4" -i "$D/social_45_frame.png" \
 -filter_complex "[0:v]scale=1080:608:flags=lanczos[vid];\
[1:v]format=rgba[fr];\
color=c=0x070B14:s=1080x1350:r=30[bgc];\
[bgc][vid]overlay=0:371:shortest=1[b1];[b1][fr]overlay=0:0[vo]" \
 -map "[vo]" -map 0:a -c:v libx264 -preset slow -crf 20 -pix_fmt yuv420p \
 -c:a aac -b:a 160k -movflags +faststart "$D/loadboot-detention-teaser-4x5.mp4"

# ── web version of the full explainer for the site (720p, smaller) ──
ffmpeg -y -hide_banner -loglevel error -i "$M" \
 -vf scale=1280:720:flags=lanczos -c:v libx264 -preset slow -crf 25 -pix_fmt yuv420p \
 -c:a aac -b:a 128k -movflags +faststart "$D/loadboot-detention-explainer-web720.mp4"

rm -f "$D"/_s[ABCD].mp4
echo "--- outputs ---"
for f in loadboot-detention-teaser-56s.mp4 loadboot-detention-teaser-4x5.mp4 loadboot-detention-explainer-web720.mp4; do
  printf '%-46s ' "$f"
  ffprobe -v error -show_entries format=duration,size -of csv=p=0 "$D/$f"
done
