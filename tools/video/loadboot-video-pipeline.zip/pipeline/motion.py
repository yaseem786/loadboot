"""Motion-craft upgrade applied to the SHARED primitives, so every section benefits
without rewriting 15 sections.

  · kinetic()  alpha-fade  ->  mask wipe reveal with a leading light edge
  · card()     flat        ->  soft drop shadow (depth) + optional scale-in overshoot
  · sa()       cross-dissolve -> vertical push (outgoing lifts as incoming rises)
  · sweep()    specular pass across a big number, once
  · rail()     persistent "RULE n OF 5" progress rail

Import this AFTER render's names are bound; call motion.install() to patch in place.
"""
import sys, math
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
import render as R
from render import F, W, H, FPS, eoc, eob, eic, seg, c01, NAVY, CARD, ORANGE, WHITE, MUT

_orig_card = R.card
_SHADOW_CACHE = {}

# ───────────────────────── depth: drop shadow under every card ─────────────────────────
def _shadow(w, h, radius, blur=20):
    """cached, half-res blurred rounded rect -> cheap soft shadow"""
    key = (w, h, radius, blur)
    if key in _SHADOW_CACHE: return _SHADOW_CACHE[key]
    hw, hh = max(4, w//2), max(4, h//2)
    m = Image.new('L', (hw + blur*2, hh + blur*2), 0)
    ImageDraw.Draw(m).rounded_rectangle([blur, blur, blur+hw, blur+hh],
                                        radius=max(2, radius//2), fill=255)
    m = m.filter(ImageFilter.GaussianBlur(blur/2.0))
    m = m.resize((w + blur*4, h + blur*4), Image.BILINEAR)
    if len(_SHADOW_CACHE) > 220: _SHADOW_CACHE.clear()
    _SHADOW_CACHE[key] = m
    return m

def card(base, box, radius=22, fill=CARD, outline=(255,255,255), ow=2, oa=0.16,
         alpha=1.0, glow=None, shadow=True, lift=14):
    if alpha <= 0.01: return
    if shadow and alpha > 0.06:
        w = int(box[2]-box[0]); h = int(box[3]-box[1])
        if w > 8 and h > 8:
            blur = 20
            m = _shadow(w, h, int(radius), blur)
            a = int(150*alpha)
            sh = Image.new('RGBA', m.size, (2, 5, 12, 0))
            sh.putalpha(m.point(lambda p: (p*a)//255))
            base.alpha_composite(sh, (int(box[0]-blur*2), int(box[1]-blur*2+lift)))
    _orig_card(base, box, radius, fill, outline, ow, oa, alpha, glow)

# ───────────────────────── text: mask wipe with a leading light edge ─────────────────────────
def kinetic(base, d, x, y, txt, size, fill, p, weight='800', anchor='lm'):
    p = c01(p)
    if p <= 0.002: return
    f = F(size, weight)
    dd = ImageDraw.Draw(base)
    bb = dd.textbbox((x, y), txt, font=f, anchor=anchor)
    pad = max(10, size//3)
    x0, y0 = int(bb[0])-pad, int(bb[1])-pad
    x1, y1 = int(bb[2])+pad, int(bb[3])+pad
    x0 = max(0, x0); y0 = max(0, y0); x1 = min(W, x1); y1 = min(H, y1)
    if x1 <= x0 or y1 <= y0: return
    bw, bh = x1-x0, y1-y0
    if p >= 0.995:
        dd.text((x, y), txt, font=f, fill=fill, anchor=anchor); return

    e = eoc(p)
    dy = (1-e)*max(10, size*0.30)          # small rise — the mask does the work
    lay = Image.new('RGBA', (bw, bh), (0,0,0,0))
    ImageDraw.Draw(lay).text((x-x0, y-y0+dy), txt, font=f, fill=fill+(255,), anchor=anchor)

    # wipe mask: solid up to the front, soft gradient edge ahead of it
    soft = max(24, int(bw*0.14))
    front = int(-soft + (bw + soft*2) * e)
    m = Image.new('L', (bw, bh), 0)
    md = ImageDraw.Draw(m)
    if front > 0: md.rectangle([0, 0, min(bw, front), bh], fill=255)
    for i in range(10):                     # cheap 10-step gradient edge
        gx = front + int(soft*i/10.0)
        if 0 <= gx < bw:
            md.rectangle([gx, 0, min(bw, gx + max(1, soft//10)), bh],
                         fill=int(255*(1 - i/10.0)))
    lay.putalpha(Image.composite(lay.getchannel('A'), Image.new('L',(bw,bh),0), m))
    base.alpha_composite(lay, (x0, y0))

    # leading light edge — a thin bright bar riding the reveal
    if 0.06 < p < 0.92 and front > 0 and front < bw:
        gl = Image.new('RGBA', (bw, bh), (0,0,0,0))
        gd = ImageDraw.Draw(gl)
        gd.rectangle([front-3, 2, front+3, bh-2], fill=ORANGE+(190,))
        gl = gl.filter(ImageFilter.GaussianBlur(5))
        base.alpha_composite(gl, (x0, y0))

# ───────────────────────── section transition: vertical push ─────────────────────────
def sa(n, a0, a1, b0, b1):
    """incoming rises into place while the outgoing lifts away — reads as a push,
    not a dip to black."""
    S = lambda s: int(s*FPS)
    ai = eoc(seg(n, S(a0), S(a1)))
    ao = eic(seg(n, S(b0), S(b1)))
    return min(ai, 1-ao), (1-ai)*82 - ao*104

# ───────────────────────── specular sweep across a big number ─────────────────────────
def sweep(base, box, p, tint=(255,255,255)):
    """one diagonal light pass over the given box; p is 0..1 across the sweep"""
    p = c01(p)
    if p <= 0.01 or p >= 0.999: return
    x0, y0, x1, y1 = [int(v) for v in box]
    w, h = x1-x0, y1-y0
    if w < 12 or h < 12: return
    band = max(60, w//4)
    cx = -band + (w + band*2)*p
    lay = Image.new('RGBA', (w, h), (0,0,0,0))
    ld = ImageDraw.Draw(lay)
    for i in range(12):
        t = i/11.0
        a = int(120 * math.sin(math.pi*t))
        px = int(cx - band/2 + band*t)
        ld.polygon([(px, h), (px+band//3, 0), (px+band//3+10, 0), (px+10, h)], fill=tint+(a,))
    lay = lay.filter(ImageFilter.GaussianBlur(7))
    base.alpha_composite(lay, (x0, y0))

# ───────────────────────── persistent rule progress rail ─────────────────────────
RULE_SPANS = [(116.68,153.73),(153.73,176.55),(176.55,198.61),(198.61,215.26),(215.26,239.46)]
def rail(base, n):
    """thin 5-segment rail while the rules are running — gives the viewer structure"""
    t = n/float(FPS)
    if t < 115.0 or t > 240.6: return
    fin = min(eoc(seg(n, int(115.0*FPS), int(116.4*FPS))),
              1-eic(seg(n, int(239.2*FPS), int(240.6*FPS))))
    if fin <= 0.02: return
    cur, frac = None, 0.0
    for i,(a,b) in enumerate(RULE_SPANS):
        if a <= t < b: cur, frac = i, (t-a)/(b-a); break
    if cur is None: cur, frac = (0,0.0) if t < RULE_SPANS[0][0] else (4,1.0)
    SW, GAP, Y, TH = 300, 16, 1024, 7
    total = SW*5 + GAP*4
    sx = (W-total)//2
    lay = Image.new('RGBA',(W,H),(0,0,0,0)); ld = ImageDraw.Draw(lay)
    for i in range(5):
        x = sx + i*(SW+GAP)
        ld.rounded_rectangle([x, Y, x+SW, Y+TH], radius=TH//2, fill=(44,60,92,int(210*fin)))
        f = 1.0 if i < cur else (frac if i == cur else 0.0)
        if f > 0.004:
            ld.rounded_rectangle([x, Y, x+int(SW*f), Y+TH], radius=TH//2,
                                 fill=ORANGE+(int(240*fin),))
    base.alpha_composite(lay)
    # no text label — the rule badge already states the number; bars alone read cleaner

# ───────────────────────── install ─────────────────────────
def install():
    R.card = card
    R.kinetic = kinetic
    return dict(card=card, kinetic=kinetic, sa=sa, sweep=sweep, rail=rail)
