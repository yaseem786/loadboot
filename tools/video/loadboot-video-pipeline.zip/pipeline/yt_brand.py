"""YouTube channel art built to YouTube's real safe areas.

  banner    2560x1440  — TV sees all of it; desktop sees the middle 2560x423 band;
                          phones see only the centred 1546x423 box, so every word that
                          matters lives inside that box.
  avatar     800x800    — renders as a circle, so nothing important near the corners
  watermark  150x150    — the transparent branding badge that sits over playback
"""
import sys, math
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw, ImageFilter
from render import F, L, LOGO, MARK, WHITE, MUT, LT, GREEN, NAVY
ORANGE = (249, 115, 22)   # the logo's own orange (#F97316), sampled from the asset

OUT = '/home/user/video/'

def bgwash(w, h, seed=0):
    """brand gradient wash, computed small and upscaled (same look as the video bg)"""
    sw, sh = 240, int(240*h/w)
    g = Image.new('RGB', (sw, sh), (7, 11, 20))
    gd = ImageDraw.Draw(g)
    gd.ellipse([sw*0.16-70, sh*0.20-70, sw*0.16+70, sh*0.20+70], fill=(20, 46, 84))
    gd.ellipse([sw*0.80-62, sh*0.74-62, sw*0.80+62, sh*0.74+62], fill=(46, 24, 30))
    gd.ellipse([sw*0.52-46, sh*0.50-46, sw*0.52+46, sh*0.50+46], fill=(26, 34, 62))
    g = g.filter(ImageFilter.GaussianBlur(24)).resize((w, h), Image.BICUBIC)
    im = g.convert('RGBA')
    # dot grid
    dl = Image.new('L', (w, h), 0); dd = ImageDraw.Draw(dl)
    step = max(40, w//64)
    for yy in range(0, h, step):
        for xx in range(0, w, step): dd.ellipse([xx, yy, xx+2, yy+2], fill=14)
    im.paste((255, 255, 255), (0, 0), dl)
    return im

def logo_at(im, cx, y, w, alpha=1.0):
    lg = LOGO.resize((w, int(LOGO.height*w/LOGO.width)), Image.LANCZOS)
    if alpha < 0.999:
        lg.putalpha(lg.getchannel('A').point(lambda p: int(p*alpha)))
    im.alpha_composite(lg, (int(cx-w/2), int(y)))
    return int(LOGO.height*w/LOGO.width)

# ─────────────────────────────── BANNER 2560x1440 ───────────────────────────────
W, H = 2560, 1440
im = bgwash(W, H)
d = ImageDraw.Draw(im)
CX, CY = W//2, H//2
# phone-safe box: 1546x423 centred
SX0, SY0 = CX-773, CY-211
SX1, SY1 = CX+773, CY+211

# faint route motif across the wide area (only decorative — outside the safe box)
lay = Image.new('RGBA', (W, H), (0,0,0,0)); ld = ImageDraw.Draw(lay)
for i, (yy, a) in enumerate([(CY-330, 26), (CY+330, 22)]):
    pts = [(x, yy + int(46*math.sin(x/430.0 + i*1.7))) for x in range(0, W, 16)]
    ld.line(pts, fill=(120, 160, 220, a), width=5)
im.alpha_composite(lay); d = ImageDraw.Draw(im)

# everything below sits inside the phone-safe box
lh = logo_at(im, CX, SY0+14, 620)
d = ImageDraw.Draw(im)
L(d, (CX, SY0+lh+66), "Get paid what you're owed.", F(74, '800'), WHITE, 'mm', 1.0, im)
L(d, (CX, SY0+lh+132), "Detention · TONU · layover · rate cons — the paperwork that pays,",
  F(33, '700'), LT, 'mm', 1.0, im)
L(d, (CX, SY0+lh+174), "explained by the people who built the software for it.",
  F(33, '700'), LT, 'mm', 1.0, im)
L(d, (CX, SY0+lh+228), "FOR CARRIERS  ·  BROKERS  ·  SHIPPERS  ·  DISPATCHERS",
  F(30, '800'), (96,165,250), 'mm', 1.0, im)
# chips
chips = [("New video weekly", ORANGE), ("loadboot.com", GREEN)]
tw = 0
for t, c in chips: tw += d.textlength(t, font=F(30,'800')) + 78
tw -= 26
x = CX - tw/2
for t, c in chips:
    w = d.textlength(t, font=F(30,'800'))
    d.rounded_rectangle([x, SY0+lh+266, x+w+52, SY0+lh+328], radius=31,
                        fill=(13,21,38), outline=c, width=3)
    L(d, (x+26+w/2, SY0+lh+297), t, F(30,'800'), c, 'mm', 1.0, im)
    x += w + 78
im.convert('RGB').save(OUT+'youtube-banner.png')
print('banner 2560x1440 — all copy inside the 1546x423 phone-safe box')

# a proof render showing the three crops YouTube uses
pv = im.copy(); pd = ImageDraw.Draw(pv)
pd.rectangle([SX0, SY0, SX1, SY1], outline=(52,211,153), width=6)
pd.rectangle([0, CY-211, W, CY+211], outline=(251,191,36), width=6)
L(pd, (SX0+16, SY0-34), "PHONE SAFE 1546x423", F(30,'800'), (52,211,153), 'lm', 1.0, pv)
L(pd, (30, CY-245), "DESKTOP 2560x423", F(30,'800'), (251,191,36), 'lm', 1.0, pv)
L(pd, (30, 44), "TV / FULL 2560x1440", F(30,'800'), (150,170,205), 'lm', 1.0, pv)
pv.convert('RGB').save(OUT+'youtube-banner-SAFE-AREA-PROOF.png')
print('safe-area proof written')

# AVATAR: owned by yt_avatar.py (built from the real logo crops) — not written here.

# ─────────────────────────────── WATERMARK 150x150 ───────────────────────────────
wm = Image.new('RGBA', (150,150), (0,0,0,0))
m2 = MARK.resize((int(112*MARK.width/MARK.height), 112), Image.LANCZOS)
m2.putalpha(m2.getchannel('A').point(lambda p: int(p*0.94)))
wm.alpha_composite(m2, ((150-m2.width)//2, (150-m2.height)//2))
wm.save(OUT+'youtube-watermark.png')
print('watermark 150x150 (transparent PNG)')
