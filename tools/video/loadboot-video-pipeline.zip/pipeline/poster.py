"""1920x1080 poster for the on-site player (same design as the YouTube thumbnail, native res)."""
import sys
sys.path.insert(0,'/home/user/video')
from PIL import Image, ImageDraw
from render import F, L, card, logo_full, ORANGE, WHITE, MUT, LT, RED

K = 1.5   # 1280x720 -> 1920x1080
def s(v): return int(round(v*K))
TW,TH = 1920,1080
t = Image.new('RGBA',(TW,TH),(7,11,20,255))
td = ImageDraw.Draw(t)
L(td,(s(64),s(120)),"THEY WAITED.",F(s(40),'800'),MUT,'lm',1.0,t)
L(td,(s(64),s(208)),"17%",F(s(178),'800'),RED,'lm',1.0,t)
L(td,(s(64),s(318)),"NEVER GET PAID",F(s(52),'800'),WHITE,'lm',1.0,t)
L(td,(s(64),s(382)),"A DOLLAR OF DETENTION",F(s(52),'800'),WHITE,'lm',1.0,t)
card(t,[s(64),s(452),s(660),s(548)],s(20),alpha=1.0,glow=ORANGE)
L(ImageDraw.Draw(t),(s(92),s(500)),"The 5 rules that fix it",F(s(42),'800'),ORANGE,'lm',1.0,t)
L(ImageDraw.Draw(t),(s(64),s(606)),"ATRI · DAT · OOIDA · DOT OIG",F(s(24),'700'),(104,124,160),'lm',1.0,t)
logo_full(t, s(64), s(636), s(250), 1.0)
card(t,[s(740),s(150),s(1216),s(570)],s(26),alpha=1.0,glow=RED)
d2=ImageDraw.Draw(t)
L(d2,(s(780),s(214)),"DETENTION BILLS AT",F(s(24),'800'),MUT,'lm',1.0,t)
L(d2,(s(780),s(278)),"$63.00/hr",F(s(64),'800'),(96,165,250),'lm',1.0,t)
L(d2,(s(780),s(354)),"AN HOUR OF TRUCK COSTS",F(s(24),'800'),MUT,'lm',1.0,t)
L(d2,(s(780),s(418)),"$66.65/hr",F(s(64),'800'),RED,'lm',1.0,t)
d2.line([(s(780),s(466)),(s(1176),s(466))],fill=(60,80,116),width=s(3))
L(d2,(s(780),s(516)),"you are $3.65/hr underwater",F(s(30),'800'),ORANGE,'lm',1.0,t)
t.convert('RGB').save('/home/user/video/loadboot-detention-explainer.jpg',quality=92)
print('poster 1920x1080 ok')
